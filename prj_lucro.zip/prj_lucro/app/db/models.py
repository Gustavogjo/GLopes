import enum
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, Float, Integer, Boolean, DateTime, Enum, ForeignKey
from sqlalchemy import Column, String, Text, Float, Integer, Boolean, DateTime, Enum, ForeignKey, JSON, func
from sqlalchemy.dialects.postgresql import UUID
from app.db.session import Base

class StatusHistoria(str, enum.Enum):
    AGUARDANDO_APROVACAO = "AGUARDANDO_APROVACAO"
    TRADUZINDO = "TRADUZINDO"
    INTERNACIONALIZACAO = "INTERNACIONALIZACAO"
    DISTRIBUICAO = "DISTRIBUICAO"
    APROVADA = "APROVADA"
    REVISAO_HUMANA = "REVISAO_HUMANA"
    LIBERADO_AUDIO = "LIBERADO_AUDIO"
    AUDIO_PRONTO = "AUDIO_PRONTO"
    ERRO_FATAL_AUDIO = "ERRO_FATAL_AUDIO"
    LIBERADO_PRODUCAO = "LIBERADO_PRODUCAO"
    LIBERADO_RENDERIZACAO = "LIBERADO_RENDERIZACAO"
    BETA_PRONTO = "BETA_PRONTO"
    ERRO_FATAL_RENDERIZACAO = "ERRO_FATAL_RENDERIZACAO"
    PUBLICADO = "PUBLICADO"
    REPROVADO_CURTO = "REPROVADO_CURTO"
    REPROVADO_PO = "REPROVADO_PO"
    APROVACAO_HUMANA_TEMPO = "APROVACAO_HUMANA_TEMPO"
    DIVIDIDA_EM_SERIE = "DIVIDIDA_EM_SERIE"
    EXCLUIDO_PERMANENTE = "EXCLUIDO_PERMANENTE"
    REPROVADO_NOTA = "REPROVADO_NOTA"

class HistoriaReddit(Base):
    __tablename__ = "historias_reddit"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    id_post_reddit = Column(String, unique=False, nullable=False, index=True)
    subreddit = Column(String(50), nullable=False)
    titulo_reddit = Column(String, nullable=False)
    texto_original = Column(Text, nullable=False)
    comentarios_reddit = Column(JSON, default=list)
    texto_narrado = Column(Text, nullable=True)
    genero_narrador = Column(String(20), nullable=True)
    justificativa_ia = Column(Text, nullable=True)
    resumo_comentarios = Column(Text, nullable=True)
    ups = Column(Integer, default=0)
    num_comments = Column(Integer, default=0)
    upvote_ratio = Column(Float, nullable=True)
    data_criacao = Column(DateTime, default=datetime.utcnow, nullable=True)
    data_analise_ia = Column(DateTime, nullable=True)
    
    # Notas das IAs (mixture of experts)
    nota_gemini = Column(Float, nullable=True)
    nota_gpt = Column(Float, nullable=True)
    nota_claude = Column(Float, nullable=True)
    nota_media = Column(Float, nullable=True)
    nota_viral = Column(Float, nullable=True)
    
    status = Column(Enum(StatusHistoria), default=StatusHistoria.AGUARDANDO_APROVACAO, nullable=False)
    
    # Geração de Gancho
    titulo_gancho = Column(String, nullable=True)
    caminho_imagem_gancho = Column(String, nullable=True)
    
    # Detalhes de Áudio
    duracao_audio_segundos = Column(Integer, nullable=True)
    velocidade_video = Column(Float, default=1.0)
    data_liberacao_audio = Column(DateTime, nullable=True)
    data_inicio_audio = Column(DateTime, nullable=True)
    data_fim_audio = Column(DateTime, nullable=True)
    
    # Rastreabilidade Financeira - Unit Economics
    custo_ia_texto = Column(Float, default=0.0)
    custo_ia_voz = Column(Float, default=0.0)
    
    # Analytics
    url_video_publicado = Column(String, nullable=True)
    nota_engajamento_youtube = Column(Float, nullable=True) # 0 a 10
    data_publicacao = Column(DateTime, nullable=True)
    visualizacoes_youtube = Column(Integer, default=0, nullable=True)
    comentarios_youtube = Column(Integer, default=0, nullable=True)
    likes_youtube = Column(Integer, default=0, nullable=True)
    
    # Exclusão e Logs
    flag_exclusao_segura = Column(Boolean, default=False, nullable=False)
    log_erro = Column(Text, nullable=True)
    
    # Internacionalização e Distribuição
    idioma = Column(String(10), default="pt", nullable=False)
    parent_id = Column(UUID(as_uuid=True), ForeignKey('historias_reddit.id'), nullable=True)
    parte_numero = Column(Integer, nullable=True)
    log_processamento = Column(Text, nullable=True)
    descricao_youtube = Column(Text, nullable=True)
    data_distribuicao = Column(DateTime, nullable=True)

class ConfiguracaoSistema(Base):
    __tablename__ = "configuracoes_sistema"

    # Operará como Singleton
    id = Column(Integer, primary_key=True, default=1)
    
    # Mapeamento de Subreddits para Busca (Separados por vírgula)
    subreddits_busca = Column(String, default="RelatosDoReddit", nullable=False)
    reddit_time_filters = Column(String, default="day", nullable=False)
    
    # Bypass Anti-Bot (Espelhamento do Navegador)
    reddit_cookie = Column(Text, nullable=True)
    reddit_user_agent = Column(String, nullable=True)
    
    # Mapeamento de Vozes ElevenLabs
    elevenlabs_voice_pt = Column(String, default="Antoni", nullable=False)
    elevenlabs_voice_en = Column(String, nullable=True)
    elevenlabs_voice_es = Column(String, nullable=True)
    
    # Credenciais OAuth2 YouTube
    youtube_client_id = Column(String, nullable=True)
    youtube_client_secret = Column(String, nullable=True)
    
    # Em vez de um único token, armazenaremos os tokens em JSON: {"pt": {...}, "en": {...}, "es": {...}}
    youtube_tokens_json = Column(JSON, default=dict, nullable=False)
    
    # Configurações de IAs (Texto)
    usar_gemini = Column(Boolean, default=True, nullable=False)
    api_key_gemini = Column(String, nullable=True)
    
    usar_anthropic = Column(Boolean, default=False, nullable=False)
    api_key_anthropic = Column(String, nullable=True)
    
    # Configurações ElevenLabs (Vozes) - Armazenará JSON: [{"key": "xxx", "active": true}, ...]
    api_keys_elevenlabs_json = Column(JSON, default=list, nullable=False)

    # Configuração de Provedor de Áudio
    usar_edge_tts = Column(Boolean, default=False, nullable=False)

class LogSistema(Base):
    __tablename__ = "logs_sistema"

    id = Column(Integer, primary_key=True, autoincrement=True)
    data_registro = Column(DateTime, default=datetime.utcnow, nullable=False)
    tipo_tarefa = Column(String, nullable=False) # Ex: "MINERACAO_REDDIT", "RENDERIZACAO"
    sucesso = Column(Boolean, nullable=False)
    detalhes = Column(Text, nullable=False) # Ex: "Foi tentado no r/RelatosDoReddit. Erro 403: Cookie expirado"

class VideoBackground(Base):
    __tablename__ = "videos_background"

    id = Column(Integer, primary_key=True, autoincrement=True)
    url_youtube = Column(String, nullable=False, unique=True)
    titulo = Column(String, nullable=True)
    caminho_arquivo = Column(String, nullable=True)
    status = Column(String, default="BAIXANDO", nullable=False) # BAIXANDO, PRONTO, ERRO
    criado_em = Column(DateTime, default=datetime.utcnow)

class EstatisticaCanal(Base):
    __tablename__ = "estatisticas_canal"

    id = Column(Integer, primary_key=True, autoincrement=True)
    data_coleta = Column(DateTime, default=datetime.utcnow, nullable=False)
    idioma = Column(String(10), default="pt", nullable=False)
    inscritos = Column(Integer, default=0)
    visualizacoes_totais = Column(Integer, default=0)
    videos_totais = Column(Integer, default=0)
