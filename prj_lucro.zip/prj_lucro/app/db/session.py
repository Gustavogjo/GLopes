from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from app.core.config import settings

import sys
from sqlalchemy.pool import NullPool

is_uvicorn = sys.argv and len(sys.argv) > 0 and "uvicorn" in sys.argv[0]

if is_uvicorn:
    engine = create_async_engine(
        settings.DATABASE_URL_ASYNC,
        echo=False,
        pool_pre_ping=True,  # Evita conexões zumbis e quedas no PostgreSQL
        pool_size=10,        # Número constante de conexões ativas na pool
        max_overflow=20      # Transbordo em picos de concorrência
    )
else:
    engine = create_async_engine(
        settings.DATABASE_URL_ASYNC,
        echo=False,
        poolclass=NullPool
    )

AsyncSessionLocal = async_sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)

Base = declarative_base()

# Generator para injeção de dependência do FastAPI
async def get_db():
    async with AsyncSessionLocal() as session:
        yield session
