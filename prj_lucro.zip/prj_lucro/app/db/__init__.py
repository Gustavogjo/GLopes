# Configurações do Alembic ficarão aqui ou inicializadas no ambiente.
# Este arquivo marca o pacote.
