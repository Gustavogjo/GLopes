import json
import asyncio
import httpx
import os
import logging
from typing import Dict, Any

import google.generativeai as genai
from openai import AsyncOpenAI
from anthropic import AsyncAnthropic

from app.core.config import settings

logger = logging.getLogger(__name__)

http_client = httpx.AsyncClient(verify=False)

# OpenAI Client para mock/fallback (Manteve-se global, se quiser, ou usar do env)
openai_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY, http_client=http_client) if settings.OPENAI_API_KEY else None

async def _get_config():
    from app.db.session import AsyncSessionLocal
    from app.db.models import ConfiguracaoSistema
    from sqlalchemy.future import select
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
        return result.scalars().first()

SYSTEM_PROMPT = """Você é um Roteirista Sênior e CRÍTICO LITERÁRIO EXTREMAMENTE RIGOROSO, especialista em storytelling e retenção para TikTok e YouTube Shorts.
Sua missão é adaptar um relato do Reddit para uma narração em áudio, transformando-o em um roteiro dinâmico, viciante e sem enrolação, MAS TAMBÉM avaliar friamente a qualidade original da história.

REGRAS DE REESCRITA (PARA VÍDEOS CURTOS):
1. RITMO ACELERADO (PACING): Corte a "gordura" e o preenchimento inútil. Elimine descrições desnecessárias (tamanho de casas, salários, idades irrelevantes) e vá direto ao ponto. Foque estritamente no conflito principal, no drama e nas reviravoltas. O relato deve ter ritmo acelerado.
2. TONE OF VOICE: Linguagem informal, estilo "storytelling de fofoca" falada. O texto deve soar coloquial. IMPORTANTE: NUNCA faça perguntas de validação ao ouvinte (ex: NÃO use "sabe?", "entende?", "viu?", "tá ligado?"). É ESTRITAMENTE PROIBIDO o uso repetitivo de vocativos e interjeições ("gente", "sério", "cara", "nossa").
3. HOOK INICIAL (SEM CLICHÊS): A PRIMEIRA frase deve ser explosiva, indo direto para a pior parte ou clímax da polêmica. A SEGUNDA frase dá o contexto rápido do narrador. É ESTRITAMENTE PROIBIDO usar frases genéricas de prender atenção como "você não vai acreditar", "fica até o final" ou "essa história é maluca". Apenas jogue o fato na cara do ouvinte.
4. IDIOMA OBRIGATÓRIO: Português do Brasil (PT-BR).
5. TRATAMENTO DE EDITS/UPDATES (ORGÂNICO): Transforme atualizações do Reddit em plot twists naturais da fala. É EXTREMAMENTE PROIBIDO dizer explicitamente "Atenção para o edit:" ou "Atualização:". Use transições naturais da linguagem falada, como: "Mas não parou por aí...", "Dias depois aconteceu o pior..." ou "E adivinha o que eu descobri?".
6. SEM CARACTERES ESPECIAIS OU EMOJIS: O texto será lido por uma IA de voz. É ESTRITAMENTE PROIBIDO usar asteriscos (** ou *), hashtags, aspas desnecessárias ou Emojis. A IA de voz pode ler "asterisco" em voz alta e estragar o vídeo. Use APENAS pontuação natural (vírgulas, pontos, interrogações e exclamações).
7. FILTRO DE PALAVRÕES (MONETIZAÇÃO): YouTube e TikTok punem/desmonetizam vídeos com palavrões pesados. Troque xingamentos pesados por palavras aceitáveis (ex: use "ferrado", "idiota", "droga", "desgraçado", "lixo"). É TOTALMENTE PROIBIDO usar qualquer xingamento ou palavra agressiva na PRIMEIRA FRASE do vídeo (nos primeiros 5 segundos).
8. ESCRITA PARA ÁUDIO IA: Escreva frases mais curtas e diretas. Evite frases excessivamente longas com muitas vírgulas, pois isso faz a IA geradora de voz perder o fôlego e soar robótica. Use pontos finais mais frequentemente.
9. CRITÉRIO DE AVALIAÇÃO E NOTA VIRAL (SEJA CÍNICO E CRÍTICO): Aja como um juiz rabugento. Procure defeitos ativamente na história antes de avaliá-la. O plot twist é previsível? A briga é infantil ou boba? Demora muito para a ação acontecer?
10. NOVA RÉGUA DE NOTAS (0.0 a 10.0): Nota 9.0 ou 10.0 deve ser reservada APENAS para relatos nível absurdo/inconcebível (ex: traições bizarras, descobertas quase criminosas, vinganças geniais). Brigas comuns de família, problemas normais de namoro ou desabafos sem clímax devem receber no máximo nota 6.0 ou 7.0. Se for chato, dê abaixo de 4.0.

Você DEVE retornar a resposta estritamente no formato JSON abaixo, sem blocos de markdown (```json) e sem nenhum texto antes ou depois. A ORDEM DOS CAMPOS É OBRIGATÓRIA:
{
  "justificativa": "Escreva 2 frases. Na primeira, seja cínico e aponte os DEFEITOS da história (ex: 'A história enrola muito e é só uma briga de família comum'). Na segunda, justifique a nota com base no nível real de absurdo.",
  "nota": float (entre 0.0 e 10.0, aplique a régua super rigorosa do item 10),
  "nota_viral": float (entre 0.0 e 10.0, quão escandalosa/polêmica é a história para o TikTok? Use a régua do item 10),
  "genero_narrador": "masculino" ou "feminino",
  "texto_reescrito": "O roteiro final otimizado. IMPORTANTE: Use \\n para quebras de linha. Não use enter real dentro desta string para não quebrar o JSON."
}"""

async def avaliar_historia_router(texto: str) -> Dict[str, Any]:
    config = await _get_config()
    
    if config and config.usar_anthropic:
        # Usa Anthropic
        if not config.api_key_anthropic:
            return {"nota": 5.0, "nota_viral": 5.0, "genero_narrador": "masculino", "justificativa": "Chave Anthropic não configurada", "texto_reescrito": "Erro: Chave não configurada"}
        
        try:
            client = AsyncAnthropic(api_key=config.api_key_anthropic, http_client=http_client)
            response = await client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=2048,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": texto}]
            )
            content = response.content[0].text
            start = content.find('{')
            end = content.rfind('}') + 1
            return json.loads(content[start:end])
        except Exception as e:
            logger.error(f"Erro Claude: {e}")
            return {"nota": None, "nota_viral": None, "genero_narrador": None, "justificativa": "Falha na API da IA (Claude)", "texto_reescrito": f"⚠️ ERRO CLAUDE:\n\n{str(e)}"}
            
    else:
        # Padrão: Usa Gemini
        if not config or not config.api_key_gemini:
            return {"nota": 5.0, "nota_viral": 5.0, "genero_narrador": "masculino", "justificativa": "Chave Gemini não configurada", "texto_reescrito": "Erro: Chave não configurada"}
        
        try:
            genai.configure(api_key=config.api_key_gemini)
            model = genai.GenerativeModel('gemini-2.5-flash', generation_config={"response_mime_type": "application/json"})
            
            response = await model.generate_content_async(f"{SYSTEM_PROMPT}\nHistória:\n{texto}")
            
            in_tokens = response.usage_metadata.prompt_token_count if hasattr(response, 'usage_metadata') and response.usage_metadata else 0
            out_tokens = response.usage_metadata.candidates_token_count if hasattr(response, 'usage_metadata') and response.usage_metadata else 0
            custo_usd = (in_tokens * 0.000000075) + (out_tokens * 0.00000030)
            logger.info(f"[GEMINI ROTEIRO] Tokens In: {in_tokens} | Out: {out_tokens} | Custo: ${custo_usd:.5f}")
            
            result = json.loads(response.text)
            result["custo_ia_texto"] = custo_usd
            return result
        except Exception as e:
            logger.error(f"Erro Gemini: {e}")
            return {"nota": None, "nota_viral": None, "genero_narrador": None, "justificativa": "Falha na API da IA (Gemini)", "texto_reescrito": f"⚠️ ERRO GEMINI:\n\n{str(e)}"}

async def gerar_gancho_imagem_e_titulo(texto: str, id_post_reddit: str, titulo_existente: str = None) -> Dict[str, Any]:
    """
    Geração do Título Gancho (Gemini) e da imagem Overlay Caixa Reddit.
    A imagem é gerada localmente em /app/assets/hooks/.
    """
    config = await _get_config()
    titulo = titulo_existente
    custo_imagem = 0.0
    
    if not titulo:
        try:
            if config and config.api_key_gemini:
                genai.configure(api_key=config.api_key_gemini)
                model = genai.GenerativeModel('gemini-2.5-flash')
                
                res_titulo = await model.generate_content_async(
                    f"Você é um especialista em retenção de público no TikTok e Shorts. Retorne APENAS um JSON válido com as seguintes chaves:\n"
                    f"1. 'titulo': Um título de altíssimo engajamento (clickbait agressivo, mas fiel à história) em PT-BR. "
                    f"Use gatilhos de forte carga emocional (vingança, traição, humilhação, choque ou segredos de família). "
                    f"Use a primeira pessoa do singular ('Eu', 'Minha'). O título deve deixar um mistério no ar (lacuna de curiosidade) para forçar o usuário a parar de rolar a tela. "
                    f"Exemplos de sucesso: 'Minha sogra tentou me destruir e se arrependeu', 'Descobri o segredo sujo da minha noiva', 'Eu me vinguei do meu chefe de forma brilhante'. "
                    f"MÁXIMO ABSOLUTO de 8 palavras. Precisa ser muito curto, impactante e direto ao ponto.\n"
                    f"2. 'prompt_visual': Um prompt visual cinematográfico em INGLÊS descrevendo o clímax da história para uma IA de imagem, hiper-realista, iluminação dramática (máx 40 palavras).\n\n"
                    f"História: {texto}"
                )
                
                in_tokens = res_titulo.usage_metadata.prompt_token_count if hasattr(res_titulo, 'usage_metadata') and res_titulo.usage_metadata else 0
                out_tokens = res_titulo.usage_metadata.candidates_token_count if hasattr(res_titulo, 'usage_metadata') and res_titulo.usage_metadata else 0
                custo_usd = (in_tokens * 0.000000075) + (out_tokens * 0.00000030)
                logger.info(f"[GEMINI TITULO] Tokens In: {in_tokens} | Out: {out_tokens} | Custo: ${custo_usd:.5f}")
                custo_imagem = custo_usd # Reutilizando a variável custo_imagem que é retornada como custo_ia_texto no final
                
                import json
                try:
                    content = res_titulo.text.strip()
                    start = content.find('{')
                    end = content.rfind('}') + 1
                    data = json.loads(content[start:end])
                    titulo = data.get('titulo', '')[:100]
                    prompt_visual = data.get('prompt_visual', titulo)
                except Exception as e:
                    logger.error(f"Erro no parse do JSON do Título: {e}")
                    titulo = res_titulo.text.strip().replace('"', '')[:100]
                    prompt_visual = titulo
        except Exception as e:
            logger.error(f"Erro Gemini Título: {e}")
            return {"titulo_gancho": None, "caminho_imagem_gancho": None, "custo_ia_texto": 0.0}
    else:
        prompt_visual = titulo

    # Geração da Imagem (Caixa do Reddit estilo Overlay)
    caminho_imagem = ""
    try:
        import os
        import time
        dir_hooks = "/app/assets/hooks"
        os.makedirs(dir_hooks, exist_ok=True)
        timestamp = int(time.time())
        # Salvando como .png pois possui cantos arredondados com fundo transparente
        caminho_temp = f"{dir_hooks}/{id_post_reddit}_{timestamp}.png"
        
        from app.services.media_services import gerar_caixa_reddit
        gerar_caixa_reddit(caminho_temp, titulo)
        caminho_imagem = caminho_temp
        
    except Exception as e:
        logger.error(f"Erro ao gerar a caixa do Reddit: {e}")
        caminho_imagem = None
            
    return {
        "titulo_gancho": titulo,
        "caminho_imagem_gancho": caminho_imagem,
        "custo_ia_texto": custo_imagem
    }

async def traduzir_roteiro(texto_narrado: str, titulo_gancho: str, idioma_destino: str) -> Dict[str, str]:
    """
    Traduz o texto narrado e o título gancho para o idioma de destino usando o Gemini (gratuito na maioria das vezes).
    Mantém a entonação de storytelling.
    """
    config = await _get_config()
    if not config or not config.api_key_gemini:
        await asyncio.sleep(0.5)
        # Mock de tradução
        return {
            "texto_traduzido": f"[Translated to {idioma_destino}] {texto_narrado}",
            "titulo_traduzido": f"[Translated to {idioma_destino}] {titulo_gancho}"
        }
        
    try:
        genai.configure(api_key=config.api_key_gemini)
        model = genai.GenerativeModel('gemini-2.5-flash', generation_config={"response_mime_type": "application/json"})
        
        prompt = f"""Você é um Roteirista e Tradutor Sênior nativo.
        Sua missão é TRADUZIR OBRIGATORIAMENTE o roteiro E O TÍTULO abaixo para o idioma: '{idioma_destino}'.
        MANTENHA EXATAMENTE o tom coloquial, as gírias adaptadas, o suspense e o ritmo narrativo acelerado.
        NÃO RESUMA a história.
        
        Roteiro original:
        {texto_narrado}
        
        Título original (TRADUZA ESTE TÍTULO PARA '{idioma_destino}'):
        {titulo_gancho}
        
        Retorne ESTRITAMENTE um JSON no seguinte formato:
        {{
            "texto_traduzido": "O roteiro traduzido com \\n para quebras de linha",
            "titulo_traduzido": "O título traduzido obrigatoriamente para {idioma_destino}"
        }}
        """
        response = await model.generate_content_async(prompt)
        
        usage = response.usage_metadata
        in_tokens = usage.prompt_token_count if usage else 0
        out_tokens = usage.candidates_token_count if usage else 0
        
        cost_in = (in_tokens / 1000) * 0.000073
        cost_out = (out_tokens / 1000) * 0.0003
        
        result_json = json.loads(response.text)
        result_json["tokens_input"] = in_tokens
        result_json["tokens_output"] = out_tokens
        result_json["custo_input"] = cost_in
        result_json["custo_output"] = cost_out
        
        return result_json
    except Exception as e:
        logger.error(f"Erro ao traduzir com Gemini: {e}")
        return {
            "texto_traduzido": f"⚠️ ERRO TRADUÇÃO: {str(e)}\n\n{texto_narrado}",
            "titulo_traduzido": titulo_gancho
        }

async def gerar_descricao_youtube(roteiro: str, titulo: str, idioma: str = "pt") -> Dict[str, Any]:
    """
    Gera título, descrição e tags engajadoras para o YouTube usando Gemini.
    """
    config = await _get_config()
    if not config or not config.api_key_gemini:
        await asyncio.sleep(0.5)
        return {"descricao": "⚠️ Chave Gemini não configurada.\n\nTítulo: ...\n\nDescrição: ...\n\nTags: #shorts", "custo_usd": 0.0}
        
    try:
        prompt = f"""Você é um especialista em SEO e Viralização do YouTube Shorts.
O idioma alvo é: {idioma}.

Recebi este roteiro de uma história (narrada) que virou um vídeo curto, e seu título provisório.
Sua missão é gerar os Metadados para o YouTube.

Título Provisório:
{titulo}

Roteiro:
{roteiro}

Retorne ESTRITAMENTE um JSON no seguinte formato:
{{
    "titulo": "(Um título matador para o YouTube, máx 60 caracteres)",
    "descricao": "(Uma descrição curta e engajadora que chame para se inscrever e curtir. Use emojis. Faça uma pergunta para os comentários no final.)",
    "tags": "(Lista de hashtags relacionadas separadas por espaço. ex: #shorts #reddit #relatos)"
}}
"""
        genai.configure(api_key=config.api_key_gemini)
        model = genai.GenerativeModel('gemini-2.5-flash', generation_config={"response_mime_type": "application/json"})
        response = await model.generate_content_async(prompt)
        
        usage = response.usage_metadata
        in_tokens = usage.prompt_token_count if usage else 0
        out_tokens = usage.candidates_token_count if usage else 0
        custo_usd = (in_tokens * 0.000000075) + (out_tokens * 0.00000030)
        
        # Validar se o JSON retornado é válido
        import json
        json_data = json.loads(response.text.strip())
        
        # Retorna a string JSON compacta
        return {"descricao": json.dumps(json_data, ensure_ascii=False), "custo_usd": custo_usd}
    except Exception as e:
        logger.error(f"Erro ao gerar descrição YouTube: {e}")
        return {"descricao": f"⚠️ Erro ao gerar com a IA: {str(e)}", "custo_usd": 0.0}

async def dividir_historia_em_serie(texto: str, num_partes: int) -> Dict[str, Any]:
    """
    Divide uma história muito longa em múltiplas partes (série), garantindo gancho no fim de uma e no começo da outra.
    """
    config = await _get_config()
    if not config or not config.api_key_gemini:
        raise Exception("Chave do Gemini não configurada.")
        
    prompt = f"""Você é um Roteirista Sênior do TikTok/YouTube Shorts especialista em criar Séries ("Parte 1", "Parte 2").
A história a seguir é MUITO LONGA e precisa ser dividida em EXATAMENTE {num_partes} partes de tamanhos semelhantes.

REGRAS CRÍTICAS:
1. PARTE 1: Começa com o gancho normal da história. A ÚLTIMA FRASE OBRIGATÓRIA DA PARTE 1 DEVE SER: "Clica no link aqui embaixo para ver a Parte 2!"
2. PARTES INTERMEDIÁRIAS: A PRIMEIRA frase deve ser um micro-resumo ("Continuando da parte anterior, onde..."). A ÚLTIMA FRASE DEVE SER: "Clica no link aqui embaixo para ver a Parte [X+1]!"
3. ÚLTIMA PARTE: A PRIMEIRA frase deve ser o micro-resumo da parte anterior. O final DEVE concluir a história (NÃO pedir para clicar na próxima parte).
4. CORTE CONTEXTUAL: Faça o corte em momentos de clímax (cliffhangers) para gerar curiosidade! NUNCA corte no meio de uma frase.
5. TONE OF VOICE: Narrador de fofoca, coloquial, informal. PROIBIDO interjeições repetitivas ("gente", "sério").
6. IDIOMA: Tudo em Português (PT-BR).
7. TAMANHO MÍNIMO (MUITO IMPORTANTE): Cada parte DEVE OBRIGATORIAMENTE ter no MÍNIMO 220 a 300 palavras. Não resuma! Mantenha ou adicione detalhes se necessário para garantir o tamanho. Partes pequenas serão penalizadas.

História Original:
{texto}

Você deve retornar ESTRITAMENTE um JSON no formato abaixo, gerando os {num_partes} blocos necessários:
{{
    "partes": [
        {{
            "parte": 1,
            "texto": "Roteiro da parte 1... \\nClica no link aqui embaixo para ver a Parte 2!"
        }},
        ... adicione os dicionários até chegar na parte {num_partes} ...
        {{
            "parte": {num_partes},
            "texto": "Continuando da parte anterior, onde... \\nRoteiro da última parte..."
        }}
    ]
}}
"""
    try:
        genai.configure(api_key=config.api_key_gemini)
        model = genai.GenerativeModel('gemini-2.5-flash', generation_config={"response_mime_type": "application/json"})
        response = await model.generate_content_async(prompt)
        
        usage = response.usage_metadata
        in_tokens = usage.prompt_token_count if usage else 0
        out_tokens = usage.candidates_token_count if usage else 0
        custo_usd = (in_tokens * 0.000000075) + (out_tokens * 0.00000030)
        
        import json
        json_data = json.loads(response.text.strip())
        json_data["custo_usd"] = custo_usd
        return json_data
    except Exception as e:
        logger.error(f"Erro ao dividir história: {e}")
        raise e

async def resumir_comentarios_ia(titulo: str, texto_original: str, comentarios: str) -> str:
    config = await _get_config()
    if not config or not config.usar_gemini or not config.api_key_gemini:
        return 'Erro: Chave Gemini não configurada ou desativada.'
        
    prompt = f"""Você é um assistente especialista em analisar comunidades do Reddit.
Abaixo está o título, a história original e uma lista de comentários dos usuários (incluindo o número de upvotes).
Sua tarefa é fazer um resumo claro e direto sobre o que a comunidade achou da história.

Responda em tópicos:
- Veredito Geral (Apoiaram o autor? Detonaram? Ficaram divididos?)
- Principais Pontos Levantados (Quais foram os argumentos mais votados?)
- Conselho/Conclusão da Comunidade

Título: {titulo}
História: {texto_original}

Comentários:
{comentarios}
"""
    try:
        genai.configure(api_key=config.api_key_gemini)
        model = genai.GenerativeModel('gemini-2.5-flash')
        response = await model.generate_content_async(prompt)
        return response.text.strip()
    except Exception as e:
        logger.error(f'Erro ao resumir comentarios: {e}')
        return f'Erro ao processar resumo: {e}'
