import os
import asyncio
import logging
import edge_tts
from typing import Tuple

logger = logging.getLogger(__name__)

# Configuração de Vozes Padrão do Edge-TTS
VOICE_MAPPING = {
    "pt": {
        "masculino": "pt-BR-AntonioNeural",
        "feminino": "pt-BR-FranciscaNeural"
    },
    "en": {
        "masculino": "en-US-ChristopherNeural",
        "feminino": "en-US-JennyNeural"
    },
    "es": {
        "masculino": "es-ES-AlvaroNeural",
        "feminino": "es-ES-ElviraNeural"
    }
}

async def gerar_audio_edge_tts(texto: str, genero_narrador: str, historia_id: str, idioma: str = "pt") -> Tuple[str, float]:
    """
    Gera o áudio usando a biblioteca edge-tts (Gratuita).
    Retorna o caminho do arquivo e o custo estimado (que é sempre 0.0).
    """
    dir_output = "/app/output"
    os.makedirs(dir_output, exist_ok=True)
    caminho_audio = f"{dir_output}/{historia_id}_temp_audio.mp3"
    
    # Seleciona a voz correta com base no idioma e gênero
    lang_voices = VOICE_MAPPING.get(idioma.lower(), VOICE_MAPPING["pt"])
    voice_id = lang_voices.get(genero_narrador.lower(), lang_voices["masculino"])
    
    import aiohttp
    import ssl
    import edge_tts.communicate
    
    # Desabilita verificação SSL global do edge_tts para websockets
    edge_tts.communicate._SSL_CTX = False
    
    try:
        communicate = edge_tts.Communicate(text=texto, voice=voice_id)
        await communicate.save(caminho_audio)
        
        logger.info(f"Áudio Edge-TTS gerado com sucesso em {caminho_audio}")
        return caminho_audio, 0.0
        
    except Exception as e:
        logger.error(f"Erro fatal na geração de áudio via Edge-TTS: {e}")
        if os.path.exists(caminho_audio):
            try: os.remove(caminho_audio)
            except: pass
        raise e
