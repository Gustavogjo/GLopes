import os
import asyncio
import logging
from typing import Tuple
from elevenlabs.client import AsyncElevenLabs
from app.core.config import settings

logger = logging.getLogger(__name__)

# Configuração de Vozes Padrão (IDs requeridos pela v2)
VOICE_MAPPING = {
    "masculino": "JBFqnCBsd6RMkjVDRZzb",  # George (Free Tier)
    "feminino": "EXAVITQu4vr4xnSDxMaL"    # Sarah (Free Tier)
}

# Custo estimado por 1000 caracteres no tier base da ElevenLabs (~$0.30 por 1k chars em alguns tiers, ou ajustável)
COST_PER_CHAR = 0.00030

async def _get_config():
    from app.db.session import AsyncSessionLocal
    from app.db.models import ConfiguracaoSistema
    from sqlalchemy.future import select
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
        return result.scalars().first()

async def gerar_audio_tts(texto: str, genero_narrador: str, historia_id: str) -> Tuple[str, float]:
    """
    Gera o áudio usando ElevenLabs, salva em disco e retorna (caminho_arquivo, custo_estimado).
    Se não houver chave API, simula a criação de um MP3 silencioso ou copia um arquivo base (Mock).
    """
    dir_output = "/app/output"
    os.makedirs(dir_output, exist_ok=True)
    caminho_audio = f"{dir_output}/{historia_id}_temp_audio.mp3"
    
    custo_estimado = len(texto) * COST_PER_CHAR
    
    config = await _get_config()
    chaves_disponiveis = []
    if config and config.api_keys_elevenlabs_json:
        # Filtra as chaves ativas do JSON [{"key": "xxx", "active": true}, ...]
        chaves_disponiveis = [item["key"].strip() for item in config.api_keys_elevenlabs_json if item.get("active") and item.get("key", "").strip()]

    if not chaves_disponiveis:
        logger.warning("Nenhuma chave ativa da ElevenLabs configurada no Banco. Executando Mock mode para TTS.")
        await asyncio.sleep(1)
        # Cria um arquivo vazio ou pequeno arquivo de áudio mockado
        import subprocess
        subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo", "-t", "95", "-q:a", "9", "-acodec", "libmp3lame", caminho_audio], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return caminho_audio, 0.0

    try:
        import websockets
        import json
        import ssl
        import base64
        
        voice_id = VOICE_MAPPING.get(genero_narrador.lower(), "ErXwobaYiN019PkySvjV")
        url = f"wss://api.elevenlabs.io/v1/text-to-speech/{voice_id}/stream-input?model_id=eleven_multilingual_v2&output_format=mp3_44100_128"
        
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        
        last_exception = None
        
        for i, chave in enumerate(chaves_disponiveis):
            logger.info(f"Gerando áudio com ElevenLabs (Chave {i+1}/{len(chaves_disponiveis)}) usando voice_id: {voice_id}")
            try:
                async with websockets.connect(url, ssl=ssl_context) as websocket:
                    # 1. Autenticação e setup inicial
                    await websocket.send(json.dumps({
                        "text": " ",
                        "voice_settings": {"stability": 0.5, "similarity_boost": 0.8},
                        "xi_api_key": chave
                    }))
                    
                    # 2. Envia o texto em partes para não sobrecarregar
                    chunk_size = 1500
                    for j in range(0, len(texto), chunk_size):
                        await websocket.send(json.dumps({
                            "text": texto[j:j+chunk_size],
                            "try_trigger_generation": True
                        }))
                    
                    # 3. Sinaliza o fim (EOS)
                    await websocket.send(json.dumps({"text": ""}))
                    
                    # 4. Recebe o MP3 em chunks de Base64 e grava
                    # Se houver erro de cota ou auth, a conexão cairá rapidamente antes de gravar muito
                    with open(caminho_audio, "wb") as f:
                        chunk_count = 0
                        while True:
                            response = await websocket.recv()
                            data = json.loads(response)
                            
                            # ElevenLabs manda um erro no JSON as vezes
                            if "error" in data or data.get("message") == "Error":
                                raise Exception(f"Erro na API da ElevenLabs: {data}")
                                
                            if data.get("audio"):
                                chunk_count += 1
                                if chunk_count % 10 == 0:
                                    logger.info(f"Baixando pacote de áudio {chunk_count} da ElevenLabs...")
                                f.write(base64.b64decode(data["audio"]))
                            if data.get("isFinal"):
                                logger.info("Download de áudio finalizado com sucesso.")
                                return caminho_audio, custo_estimado
                                
            except Exception as e:
                logger.warning(f"Chave {i+1} falhou. Motivo: {e}")
                last_exception = e
                # Se falhar no meio, apaga o arquivo corrompido para a proxima tentativa tentar limpo
                if os.path.exists(caminho_audio):
                    try: os.remove(caminho_audio)
                    except: pass
                continue # Tenta a proxima chave
                
        # Se chegou aqui, nenhuma chave funcionou
        logger.error(f"Todas as {len(chaves_disponiveis)} chaves ativas da ElevenLabs falharam.")
        raise last_exception or Exception("Falha na geração de áudio (Sem chaves válidas ou erro de quota em todas)")
        
    except Exception as e:
        logger.error(f"Erro fatal no motor de áudio: {e}")
        raise e
