import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.db.models import ConfiguracaoSistema, HistoriaReddit
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

logger = logging.getLogger(__name__)

async def get_youtube_credentials(db: AsyncSession, lang: str = "pt") -> Credentials:
    """
    Busca os tokens armazenados no banco de dados e retorna o objeto Credentials do Google.
    Este objeto já implementa lógica interna para usar o refresh_token automaticamente quando expirado.
    """
    result = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
    config = result.scalars().first()

    if not config or not config.youtube_client_id or not config.youtube_tokens_json:
        raise ValueError("O sistema ainda não está autenticado com o YouTube ou falta Client ID.")

    token_data = config.youtube_tokens_json.get(lang)
    if not token_data or not token_data.get("access_token"):
        raise ValueError(f"O canal para o idioma '{lang}' não está autenticado.")

    credentials = Credentials(
        token=token_data.get("access_token"),
        refresh_token=token_data.get("refresh_token"),
        token_uri="https://oauth2.googleapis.com/token",
        client_id=config.youtube_client_id,
        client_secret=config.youtube_client_secret
    )
    
    return credentials

async def fazer_upload_video(historia: HistoriaReddit, db: AsyncSession, video_path: str = None):
    """
    Realiza o upload do arquivo mp4 renderizado para o YouTube via API no canal correto.
    Retorna o ID do vídeo publicado.
    """
    idioma_video = historia.idioma or "pt"
    creds = await get_youtube_credentials(db, lang=idioma_video)
    youtube = build("youtube", "v3", credentials=creds)
    
    if not video_path:
        video_path = f"/app/output/BETA_{historia.id}_final.mp4"
    titulo = historia.titulo_gancho or historia.titulo_reddit
    descricao_completa = historia.descricao_youtube or ""
    
    tags_disponiveis = []
    
    if descricao_completa:
        import re
        import json
        
        try:
            desc_json = json.loads(descricao_completa)
            titulo = desc_json.get("titulo", titulo)
            descricao = desc_json.get("descricao", "")
            tags_str = desc_json.get("tags", "")
            if tags_str:
                descricao += f"\n\n{tags_str}"
            tags_disponiveis = re.findall(r'#\w+', tags_str)
        except json.JSONDecodeError:
            # Fallback for old textual format
            match_titulo = re.search(r'TITULO VIRAL:\s*(.*?)(?=\nDESCRICAO|\n\nDESCRICAO|$)', descricao_completa, re.IGNORECASE | re.DOTALL)
            if match_titulo:
                titulo = match_titulo.group(1).strip()
                
            tags_disponiveis = re.findall(r'#\w+', descricao_completa)
                
            desc_limpa = re.sub(r'TITULO VIRAL:.*?(?=\nDESCRICAO|\n\nDESCRICAO|$)', '', descricao_completa, flags=re.IGNORECASE | re.DOTALL).strip()
            desc_limpa = re.sub(r'DESCRICAO:\s*', '', desc_limpa, flags=re.IGNORECASE)
            desc_limpa = re.sub(r'TAGS:\s*', '\n\n', desc_limpa, flags=re.IGNORECASE)
            descricao = desc_limpa.strip()
    else:
        descricao = "Relato incrível do Reddit! Deixe seu like e se inscreva. #shorts #reddit #relatos"
        
    # Anexar tags no título desde que caiba no limite de 100 caracteres do YouTube
    for tag in tags_disponiveis:
        if len(titulo) + len(tag) + 1 <= 95:
            if tag.lower() not in titulo.lower():
                titulo += f" {tag}"
                
    # Respeitar limite estrito do youtube por precaução
    if len(titulo) > 95:
        titulo = titulo[:95] + "..."
    
    body = {
        "snippet": {
            "title": titulo,
            "description": descricao,
            "categoryId": "24" # Entretenimento
        },
        "status": {
            "privacyStatus": "public",
            "selfDeclaredMadeForKids": False
        }
    }
    
    media = MediaFileUpload(
        video_path,
        chunksize=1024 * 1024 * 2, # 2MB chunk
        resumable=True,
        mimetype="video/mp4"
    )
    
    logger.info(f"Iniciando upload do vídeo {video_path} para o YouTube...")
    
    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=media
    )
    
    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            progress = int(status.progress() * 100)
            logger.info(f"Progresso do Upload (YouTube): {progress}%")
            
    video_id = response.get("id")
    logger.info(f"Upload finalizado com sucesso! Video ID: {video_id}")
    
    # Fazer upload da capa (thumbnail) customizada do vídeo
    imagem_gancho_path = historia.caminho_imagem_gancho
    if imagem_gancho_path:
        import os
        if os.path.exists(imagem_gancho_path):
            try:
                logger.info(f"Fazendo upload da capa (thumbnail) {imagem_gancho_path} para o vídeo {video_id}...")
                youtube.thumbnails().set(
                    videoId=video_id,
                    media_body=MediaFileUpload(imagem_gancho_path)
                ).execute()
                logger.info("Thumbnail customizada enviada com sucesso ao YouTube.")
            except Exception as e:
                logger.warning(f"Erro ao enviar thumbnail customizada para o YouTube (alguns canais de Shorts não têm permissão de thumbnail customizada via API): {e}")
                
    return video_id

async def obter_metricas_youtube(video_id: str, idioma: str, db: AsyncSession):
    """
    Busca métricas oficiais de um vídeo publicado usando a API Data v3 do YouTube.
    Retorna (views, likes, comments).
    """
    try:
        creds = await get_youtube_credentials(db, lang=idioma)
        youtube = build("youtube", "v3", credentials=creds)
        
        request = youtube.videos().list(
            part="statistics",
            id=video_id
        )
        response = request.execute()
        
        if response.get("items"):
            stats = response["items"][0]["statistics"]
            views = int(stats.get("viewCount", 0))
            likes = int(stats.get("likeCount", 0))
            comments = int(stats.get("commentCount", 0))
            return views, likes, comments
    except Exception as e:
        logger.error(f"Erro ao buscar métricas para o vídeo {video_id}: {str(e)}")
        
    return 0, 0, 0

async def obter_estatisticas_canal(db: AsyncSession, lang: str = "pt") -> dict:
    """
    Busca estatísticas reais do canal no YouTube (Inscritos, Visualizações e Vídeos totais).
    """
    try:
        creds = await get_youtube_credentials(db, lang=lang)
        youtube = build("youtube", "v3", credentials=creds)
        
        request = youtube.channels().list(
            part="statistics",
            mine=True
        )
        response = request.execute()
        
        if response.get("items"):
            stats = response["items"][0]["statistics"]
            return {
                "inscritos": int(stats.get("subscriberCount", 0)),
                "visualizacoes_totais": int(stats.get("viewCount", 0)),
                "videos_totais": int(stats.get("videoCount", 0))
            }
        return {"inscritos": 0, "visualizacoes_totais": 0, "videos_totais": 0}
    except Exception as e:
        logger.error(f"Erro ao buscar estatísticas do canal YouTube: {e}")
        return {"inscritos": 0, "visualizacoes_totais": 0, "videos_totais": 0}
