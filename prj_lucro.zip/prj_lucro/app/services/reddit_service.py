import httpx
import logging
from app.core.config import settings

logger = logging.getLogger(__name__)

def obter_submissions(subreddits=["RelatosDoReddit"], time_filters=["day"], limit=5, custom_cookie=None, custom_user_agent=None):
    """
    Busca X posts (limit) nos subreddits indicados usando a rota .json pública.
    """
    submissions = []
    erros = []
    
    headers = {
        "User-Agent": custom_user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    if custom_cookie:
        headers["Cookie"] = custom_cookie

    with httpx.Client(headers=headers, verify=False) as client:
        for sub in subreddits:
            url = f"https://www.reddit.com/r/{sub}/top.json?t=day&limit={limit}"
            logger.info(f"Buscando posts via rota pública JSON no r/{sub}...")
            
            try:
                response = client.get(url, timeout=15.0)
                response.raise_for_status()
                data = response.json()
                
                posts = data.get("data", {}).get("children", [])
                
                for p in posts:
                    post_data = p["data"]
                    # Ignorar posts muito curtos ou sem texto (apenas imagem/link)
                    texto = post_data.get("selftext", "")
                    if len(texto) < 100:
                        continue
                        
                    post_id = post_data["id"]
                    
                    # Buscar comentários do post
                    comentarios_texto = obter_comentarios_post(
                        post_id, 
                        limit=20, 
                        sub=sub, 
                        custom_cookie=custom_cookie, 
                        custom_user_agent=custom_user_agent
                    )
                        
                    submissions.append({
                        "id": post_id,
                        "subreddit": sub,
                        "title": post_data["title"],
                        "selftext": texto,
                        "comentarios_reddit": comentarios_texto,
                        "ups": post_data.get("ups", 0),
                        "num_comments": post_data.get("num_comments", 0),
                        "upvote_ratio": post_data.get("upvote_ratio", 0.0)
                    })
                    
            except httpx.HTTPStatusError as e:
                erro_msg = f"Erro {e.response.status_code} no r/{sub}: O Cookie pode ter expirado ou o Reddit bloqueou."
                logger.error(erro_msg)
                erros.append(erro_msg)
            except Exception as e:
                erro_msg = f"Erro inesperado no r/{sub}: {str(e)}"
                logger.error(erro_msg)
                erros.append(erro_msg)
                
    return submissions, erros

def testar_conexao_reddit(subreddits=["RelatosDoReddit"], limit=5, custom_cookie=None, custom_user_agent=None):
    """
    Função de teste para o Dashboard. Retorna detalhes da requisição para facilitar o debug manual.
    """
    resultados = []
    headers = {
        "User-Agent": custom_user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    if custom_cookie:
        headers["Cookie"] = custom_cookie

    with httpx.Client(headers=headers, verify=False) as client:
        for sub in subreddits:
            url = f"https://www.reddit.com/r/{sub}/top.json?t=day&limit={limit}"
            resultado = {"url_tentada": url, "sucesso": False, "erro": None, "quantidade_posts": 0}
            
            try:
                response = client.get(url, timeout=15.0)
                response.raise_for_status()
                data = response.json()
                posts = data.get("data", {}).get("children", [])
                resultado["sucesso"] = True
                resultado["quantidade_posts"] = len(posts)
            except httpx.HTTPStatusError as e:
                resultado["erro"] = f"Erro HTTP {e.response.status_code}: {e.response.text[:200]}"
            except Exception as e:
                resultado["erro"] = str(e)
                
            resultados.append(resultado)
            
    return resultados

def obter_comentarios_post(post_id, limit=10, sub=None, custom_cookie=None, custom_user_agent=None):
    url = f"https://www.reddit.com/comments/{post_id}.json?sort=top&limit=100"
    if sub:
        url = f"https://www.reddit.com/r/{sub}/comments/{post_id}.json?sort=top&limit=100"
    
    headers = {
        "User-Agent": custom_user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    if custom_cookie:
        headers["Cookie"] = custom_cookie
        
    try:
        with httpx.Client(headers=headers, verify=False) as client:
            resp = client.get(url, timeout=10.0)
            if resp.status_code == 200:
                data = resp.json()
                threads = []
                if isinstance(data, list) and len(data) > 1:
                    children = data[1].get('data', {}).get('children', [])
                    for child in children:
                        if child['kind'] == 't1':
                            c_data = child['data']
                            text = c_data.get('body', '').strip().replace('\n', '<br>')
                            score = c_data.get('score', 0)
                            is_op = c_data.get('is_submitter', False)
                            
                            if not text or text == "[deleted]":
                                continue
                                
                            op_tag = "👑 OP: " if is_op else ""
                            thread_text = f"[👍 {score}] {op_tag}{text}"
                            
                            # Buscar respostas (Nível 2)
                            replies_l2 = c_data.get('replies')
                            if isinstance(replies_l2, dict):
                                rep2_children = replies_l2.get('data', {}).get('children', [])
                                rep2_count = 0
                                for rep2 in rep2_children:
                                    if rep2['kind'] == 't1':
                                        r2_data = rep2['data']
                                        r2_text = r2_data.get('body', '').strip().replace('\n', '<br>')
                                        r2_score = r2_data.get('score', 0)
                                        r2_is_op = r2_data.get('is_submitter', False)
                                        
                                        if r2_text and r2_text != "[deleted]":
                                            r2_op_tag = "👑 OP: " if r2_is_op else ""
                                            thread_text += f"\n    ↳ [👍 {r2_score}] {r2_op_tag}{r2_text}"
                                            rep2_count += 1
                                            
                                            # Buscar respostas (Nível 3)
                                            replies_l3 = r2_data.get('replies')
                                            if isinstance(replies_l3, dict):
                                                rep3_children = replies_l3.get('data', {}).get('children', [])
                                                rep3_count = 0
                                                for rep3 in rep3_children:
                                                    if rep3['kind'] == 't1':
                                                        r3_data = rep3['data']
                                                        r3_text = r3_data.get('body', '').strip().replace('\n', '<br>')
                                                        r3_score = r3_data.get('score', 0)
                                                        r3_is_op = r3_data.get('is_submitter', False)
                                                        
                                                        if r3_text and r3_text != "[deleted]":
                                                            r3_op_tag = "👑 OP: " if r3_is_op else ""
                                                            thread_text += f"\n        ↳ [👍 {r3_score}] {r3_op_tag}{r3_text}"
                                                            rep3_count += 1
                                                            if rep3_count >= 10:
                                                                break
                                                                
                                            if rep2_count >= 10:
                                                break
                                                
                            threads.append(thread_text)
                            if len(threads) >= limit:
                                break
                return "\n\n---\n\n".join(threads)
    except Exception as e:
        logger.error(f"Erro ao buscar comentarios: {e}")
    return ""
