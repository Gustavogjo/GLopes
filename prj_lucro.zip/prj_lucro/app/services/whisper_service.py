import json
import os
import logging
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)

def transcrever_audio_local(caminho_audio: str, historia_id: str) -> Tuple[str, Dict[str, Any]]:
    """
    Carrega o modelo Whisper localmente, transcreve o áudio com word-level timestamps e
    salva um JSON estruturado. Retorna (caminho_json, dict_transcricao).
    Executa de forma síncrona pois é pesado de CPU, ideal para rodar num thread/process pool do Celery.
    """
    import whisper
    
    dir_output = "/app/output"
    os.makedirs(dir_output, exist_ok=True)
    caminho_json = f"{dir_output}/{historia_id}_temp_subs.json"
    
    logger.info(f"Carregando modelo Whisper (base) para transcrever {caminho_audio}")
    model = whisper.load_model("base")
    
    logger.info("Iniciando transcrição com word_timestamps=True...")
    result = model.transcribe(caminho_audio, word_timestamps=True, language="pt")
    
    # Salvar em JSON para debug ou reuso
    with open(caminho_json, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
        
    return caminho_json, result
