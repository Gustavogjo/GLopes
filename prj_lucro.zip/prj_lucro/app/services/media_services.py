import os
import random
import traceback
import ffmpeg
import math
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

def formatar_tempo_ass(segundos: float) -> str:
    """Converte segundos float para o formato de tempo do ASS: H:MM:SS.cs"""
    h = int(segundos // 3600)
    m = int((segundos % 3600) // 60)
    s = int(segundos % 60)
    cs = int(round((segundos - int(segundos)) * 100))
    if cs == 100:
        cs = 99
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

def gerar_arquivo_ass(json_whisper: Dict[str, Any], caminho_ass: str, atempo_val: float = 1.0):
    """
    Converte o output estruturado do Whisper em um arquivo de legendas avançado .ass,
    focado no estilo 'palavras gigantes no centro da tela'.
    Aplica a correção de atempo diretamente nos timestamps.
    """
    ass_header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Montserrat,120,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,8,4,5,10,10,10,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    linhas_eventos = []
    
    for segment in json_whisper.get("segments", []):
        for word_info in segment.get("words", []):
            word = word_info.get("word", "").strip()
            if not word:
                continue
                
            # Corrige os tempos se o áudio será acelerado no FFmpeg
            start = word_info["start"] / atempo_val
            end = word_info["end"] / atempo_val
            
            # Para evitar sobreposições ou buracos secos (opcional), mas vamos usar exato
            start_str = formatar_tempo_ass(start)
            end_str = formatar_tempo_ass(end)
            
            # \an5 garante alinhamento central (X e Y)
            text_ass = f"{{\\an5}}{word}"
            linhas_eventos.append(f"Dialogue: 0,{start_str},{end_str},Default,,0,0,0,,{text_ass}")

    with open(caminho_ass, "w", encoding="utf-8") as f:
        f.write(ass_header)
        f.write("\n".join(linhas_eventos))

def renderizar_video_complexo(
    imagem_gancho_path: str,
    video_fundo_path: str,
    audio_path: str,
    saida_path: str,
    duracao_audio: float,
    atempo_val: float,
    titulo_gancho: str,
    json_whisper: Dict[str, Any],
    historia_id: str,
    start_time_bg: float = 0.0
) -> str:
    """
    Constrói o grafo FFmpeg: Gancho -> Video Fundo | Áudio + atempo | Legendas.
    Retorna string vazia se sucesso, ou string com o erro.
    """
    dir_output = "/app/output"
    caminho_ass = f"{dir_output}/{historia_id}_temp.ass"
    
    try:
        # 1. Gerar arquivo de legenda
        gerar_arquivo_ass(json_whisper, caminho_ass, atempo_val)
        
        # Duração ajustada do áudio final
        duracao_final_audio = duracao_audio / atempo_val
        
        # Stream 2: Vídeo de fundo agora toca desde o 0s pela duracao_final_audio inteira
        bg_in = (
            ffmpeg.input(video_fundo_path, ss=start_time_bg, t=duracao_final_audio)
            .filter('scale', 1080, 1920, force_original_aspect_ratio='increase')
            .filter('crop', 1080, 1920)
            .filter('setsar', 1)
            .filter('fps', fps=30)
        )
        
        # Stream 1: Imagem da Caixa do Reddit (com fade out no alpha aos 2.5s)
        img_in = (
            ffmpeg.input(imagem_gancho_path, loop=1, t=3.0, framerate=30)
            .filter('scale', 1080, 1920)
            .filter('format', 'rgba')
            .filter('fade', t='out', st=2.5, d=0.5, alpha=1)
        )
        
        # Sobrepõe a imagem no fundo
        video_track = ffmpeg.overlay(bg_in, img_in, x=0, y=0, eof_action='pass')
        
        # Aplica legendas
        video_track = video_track.filter('ass', caminho_ass)
        
        # Stream de Áudio
        audio_in = ffmpeg.input(audio_path)
        if atempo_val != 1.0:
            audio_in = audio_in.filter('atempo', atempo_val)
            
        # 3. Compila e Roda
        out = ffmpeg.output(
            video_track,
            audio_in,
            saida_path,
            vcodec='libx264',
            preset='fast',
            acodec='aac',
            audio_bitrate='128k',
            video_bitrate='3000k',
            r=30,
            pix_fmt='yuv420p',
            shortest=None # Para garantir que acabe com o menor stream, que deve ser o aúdio
        )
        
        import subprocess
        args = ffmpeg.compile(out, overwrite_output=True)
        
        # Inicia o FFmpeg e lê o stderr em tempo real
        process = subprocess.Popen(args, stderr=subprocess.PIPE, universal_newlines=True)
        
        # FFmpeg joga o progresso no stderr
        log_counter = 0
        for line in process.stderr:
            line_str = line.strip()
            # Logar apenas linhas relevantes de progresso para não floodar
            if "frame=" in line_str or "time=" in line_str:
                log_counter += 1
                if log_counter % 15 == 0:  # Mostrar a cada ~0.5s (30fps)
                    logger.info(f"FFmpeg Progresso: {line_str}")
            elif "Error" in line_str or "Invalid" in line_str:
                logger.warning(f"FFmpeg Warning: {line_str}")
                
        process.wait()
        if process.returncode != 0:
            return "Erro FFmpeg durante a execução"
            
        return "" # Sucesso
        
    except ffmpeg.Error as e:
        stderr = e.stderr.decode('utf8', errors='ignore') if e.stderr else "Erro FFmpeg desconhecido"
        logger.error(f"FFmpeg Error: {stderr}")
        return stderr
    except Exception as e:
        logger.error(f"Erro na renderização: {e}")
        return str(e)

def gerar_caixa_reddit(caminho_imagem: str, titulo: str):
    from PIL import Image, ImageDraw, ImageFont
    import os
    import urllib.request

    try:
        # Create a transparent base 1080x1920
        img = Image.new("RGBA", (1080, 1920), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        
        font_dir = "/app/assets/fonts"
        os.makedirs(font_dir, exist_ok=True)
        font_path_bold = os.path.join(font_dir, "Montserrat-Black.ttf")
        font_path_reg = os.path.join(font_dir, "Montserrat-Regular.ttf")
        
        # Download fonts if missing
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        if not os.path.exists(font_path_bold):
            try:
                with urllib.request.urlopen("https://github.com/JulietaUla/Montserrat/raw/master/fonts/ttf/Montserrat-Black.ttf", context=ctx) as response, open(font_path_bold, 'wb') as out_file:
                    out_file.write(response.read())
            except Exception as e:
                logger.error(f"Erro ao baixar Montserrat-Black: {e}")
                
        if not os.path.exists(font_path_reg):
            try:
                with urllib.request.urlopen("https://github.com/JulietaUla/Montserrat/raw/master/fonts/ttf/Montserrat-SemiBold.ttf", context=ctx) as response, open(font_path_reg, 'wb') as out_file:
                    out_file.write(response.read())
            except Exception as e:
                logger.error(f"Erro ao baixar Montserrat-SemiBold: {e}")
                font_path_reg = font_path_bold

        def wrap_text(text, font, max_width):
            words = text.split()
            lines = []
            current_line = []
            for word in words:
                current_line.append(word)
                bbox = draw.textbbox((0,0), " ".join(current_line), font=font)
                if (bbox[2] - bbox[0]) > max_width:
                    current_line.pop()
                    if current_line:
                        lines.append(" ".join(current_line))
                    current_line = [word]
            if current_line:
                lines.append(" ".join(current_line))
            return lines

        largura_img, altura_img = 1080, 1920
        box_width = int(largura_img * 0.85)
        margin = 50
        max_text_width = box_width - (margin * 2)
        
        font_size = 65
        try:
            font_title = ImageFont.truetype(font_path_bold, font_size)
            font_user = ImageFont.truetype(font_path_reg, 32)
        except:
            font_title = ImageFont.load_default()
            font_user = ImageFont.load_default()
            
        linhas = wrap_text(titulo, font_title, max_text_width)
        
        bbox_ref = draw.textbbox((0, 0), "A", font=font_title)
        altura_linha = bbox_ref[3] - bbox_ref[1] + 20
        altura_textos = altura_linha * len(linhas)
        
        header_height = 80
        box_height = header_height + altura_textos + int(margin * 2.5)
        
        x_box = (largura_img - box_width) // 2
        y_box = (altura_img - box_height) // 2
        
        # Shadow
        draw.rounded_rectangle([x_box+10, y_box+10, x_box + box_width + 10, y_box + box_height + 10], radius=35, fill=(0, 0, 0, 100))
        # Main box
        draw.rounded_rectangle([x_box, y_box, x_box + box_width, y_box + box_height], radius=35, fill=(255, 255, 255, 255))
        
        r_avatar = 35
        x_avatar = x_box + margin
        y_avatar = y_box + margin
        
        logo_path = "/app/assets/fonts/reddit_logo.png"
        if not os.path.exists(logo_path):
            try:
                req = urllib.request.Request(
                    "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Reddit_logo.svg/120px-Reddit_logo.svg.png",
                    headers={'User-Agent': 'Mozilla/5.0'}
                )
                with urllib.request.urlopen(req, context=ctx) as response, open(logo_path, 'wb') as out_file:
                    out_file.write(response.read())
            except Exception as e:
                logger.error(f"Erro ao baixar reddit logo: {e}")
                
        try:
            logo_img = Image.open(logo_path).convert("RGBA")
            logo_img = logo_img.resize((r_avatar*2, r_avatar*2), Image.Resampling.LANCZOS)
            img.paste(logo_img, (x_avatar, y_avatar), logo_img)
        except:
            draw.ellipse([x_avatar, y_avatar, x_avatar + r_avatar*2, y_avatar + r_avatar*2], fill=(255, 69, 0, 255))
        
        x_user = x_avatar + (r_avatar*2) + 20
        y_user = y_avatar + 18
        draw.text((x_user, y_user), "@RedditRelatosViral • 5h", font=font_user, fill=(100, 100, 100, 255))
        
        y_text = y_avatar + (r_avatar*2) + 40
        for linha in linhas:
            draw.text((x_box + margin, y_text), linha, font=font_title, fill=(20, 20, 20, 255))
            y_text += altura_linha
            
        img.save(caminho_imagem)
        logger.info(f"Caixa Reddit gerada com SUCESSO: {caminho_imagem}")
    except Exception as e:
        logger.error(f"Erro ao gerar caixa Reddit: {e}")

def tatuar_capa(caminho_imagem: str, texto: str):
    from PIL import Image, ImageDraw, ImageFont
    import os
    import urllib.request

    try:
        if not os.path.exists(caminho_imagem):
            return
            
        img = Image.open(caminho_imagem).convert("RGBA")
        draw = ImageDraw.Draw(img)
        
        font_dir = "/app/assets/fonts"
        os.makedirs(font_dir, exist_ok=True)
        font_path = os.path.join(font_dir, "Montserrat-Black.ttf")
        
        if not os.path.exists(font_path):
            try:
                import ssl
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                url = "https://github.com/JulietaUla/Montserrat/raw/master/fonts/ttf/Montserrat-Black.ttf"
                with urllib.request.urlopen(url, context=ctx) as response, open(font_path, 'wb') as out_file:
                    out_file.write(response.read())
            except Exception as e:
                logger.error(f"Erro ao baixar fonte: {e}")
                
        def wrap_text(text, font, max_width):
            words = text.split()
            lines = []
            current_line = []
            for word in words:
                current_line.append(word)
                bbox = draw.textbbox((0,0), " ".join(current_line), font=font)
                if (bbox[2] - bbox[0]) > max_width:
                    current_line.pop()
                    if current_line:
                        lines.append(" ".join(current_line))
                    current_line = [word]
            if current_line:
                lines.append(" ".join(current_line))
            return lines

        largura_img, altura_img = img.size
        margin = 60
        max_width = largura_img - (margin * 2)
        
        font_size = 140
        try:
            font = ImageFont.truetype(font_path, font_size)
            linhas = wrap_text(texto.upper(), font, max_width)
            
            # Reduz tamanho da fonte se o texto for muito longo (mais de 4 linhas)
            while len(linhas) > 4 and font_size > 60:
                font_size -= 10
                font = ImageFont.truetype(font_path, font_size)
                linhas = wrap_text(texto.upper(), font, max_width)
        except:
            font = ImageFont.load_default()
            linhas = [texto.upper()]

        # Calcula espacamento e altura total
        bbox_ref = draw.textbbox((0, 0), "A", font=font)
        altura_linha = bbox_ref[3] - bbox_ref[1] + 20
        altura_total = altura_linha * len(linhas)
        
        # Subir um pouco para nao ficar exatamente no meio tampando algo importante
        y_text = (altura_img - altura_total) / 2 - 100
        
        for linha in linhas:
            bbox_linha = draw.textbbox((0, 0), linha, font=font)
            largura_texto = bbox_linha[2] - bbox_linha[0]
            x_text = (largura_img - largura_texto) / 2
            
            # Stroke / Borda mais suave (8px em vez de 12px)
            stroke_width = max(2, int(font_size * 0.06))
            for adj_x in range(-stroke_width, stroke_width+1, 2):
                for adj_y in range(-stroke_width, stroke_width+1, 2):
                    draw.text((x_text + adj_x, y_text + adj_y), linha, font=font, fill=(0, 0, 0, 255))
            
            # Sombra atras da borda
            draw.text((x_text + stroke_width + 4, y_text + stroke_width + 4), linha, font=font, fill=(0, 0, 0, 200))
            
            # Texto principal
            draw.text((x_text, y_text), linha, font=font, fill=(255, 255, 255, 255))
            
            y_text += altura_linha
            
        img_rgb = img.convert("RGB")
        img_rgb.save(caminho_imagem)
        logger.info(f"Capa tatuada com SUCESSO e texto dinamico: {caminho_imagem}")
    except Exception as e:
        logger.error(f"Erro ao tatuar capa: {e}")




