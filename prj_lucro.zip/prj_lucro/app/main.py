from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.api.router import router as historias_router
from app.api.router_ui import router_ui
from app.api.router_series import router_series
import os
import logging
from contextlib import asynccontextmanager
from sqlalchemy import text
from app.db.session import engine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        async with engine.begin() as conn:
            await conn.execute(text("SELECT 1"))
        logger.info("Conexão com PostgreSQL [OK]")
        print("Conexão com PostgreSQL [OK]")
    except Exception as e:
        logger.error(f"Falha ao conectar no PostgreSQL: {e}")
        print(f"Falha ao conectar no PostgreSQL: {e}")
    yield
    await engine.dispose()

app = FastAPI(title="Fábrica Automatizada de Vídeos", lifespan=lifespan)

# Garante a existência dos diretórios críticos e estáticos locais
os.makedirs("/app/output", exist_ok=True)
os.makedirs("/app/assets", exist_ok=True)
os.makedirs("app/static", exist_ok=True)

templates = Jinja2Templates(directory="app/templates")

try:
    # Monta UI Estática
    app.mount("/static", StaticFiles(directory="app/static"), name="static")
    # Monta os volumes do Docker global (permitindo fallback para caminhos locais fora do Docker)
    app.mount("/assets", StaticFiles(directory="/app/assets" if os.path.exists("/app/assets") else "app/assets"), name="assets")
    app.mount("/output", StaticFiles(directory="/app/output" if os.path.exists("/app/output") else "app/output"), name="output")
except Exception as e:
    logger.warning(f"Aviso de StaticFiles: {e}")

# Inclusão dos Roteadores
app.include_router(router_ui)  # Roteador da Interface Web (Dashboard)
app.include_router(router_series) # Roteador das Histórias em Séries
app.include_router(historias_router, prefix="/api")  # Roteador de API isolado

# Handlers amigáveis de Erro para a UI
@app.exception_handler(404)
async def not_found_handler(request: Request, exc: Exception):
    return templates.TemplateResponse(request=request, name="error.html", context={"code": 404, "message": "Página não encontrada."}, status_code=404)

@app.exception_handler(500)
async def internal_server_error_handler(request: Request, exc: Exception):
    return templates.TemplateResponse(request=request, name="error.html", context={"code": 500, "message": "Erro interno do servidor."}, status_code=500)
