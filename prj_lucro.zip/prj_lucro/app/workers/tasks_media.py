import asyncio
import uuid
import os
import random
import logging
import json
from celery import shared_task
from sqlalchemy.future import select
from app.db.session import AsyncSessionLocal, engine
from app.db.models import HistoriaReddit, StatusHistoria
from app.services.elevenlabs_service import gerar_audio_tts
from app.services.whisper_service import transcrever_audio_local
from app.services.media_services import renderizar_video_complexo
import ffmpeg

logger = logging.getLogger(__name__)

@shared_task(bind=True, max_retries=1)
def gerar_audio_task(self, historia_id: str):
    asyncio.run(processar_audio(historia_id))

async def processar_audio(historia_id: str):
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    r.set("processing_audio_id", historia_id)
    try:
        await engine.dispose()
        async with AsyncSessionLocal() as db:
            result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == uuid.UUID(historia_id)))
            historia = result.scalars().first()
            
            if not historia or historia.status != StatusHistoria.LIBERADO_AUDIO:
                logger.warning(f"Historia {historia_id} não pronta para audio.")
                return

            async def add_log(msg: str):
                from datetime import datetime
                now = datetime.now().strftime("%d/%m %H:%M:%S")
                log_line = f"[{now}] {msg}\n"
                logger.info(msg)
                if getattr(historia, 'log_processamento', None):
                    historia.log_processamento += log_line
                else:
                    historia.log_processamento = log_line
                await db.commit()

            caminho_audio = None
            caminho_json = None
            
            try:
                from datetime import datetime
                historia.data_inicio_audio = datetime.utcnow()
                await db.commit()
                
                await add_log(f"Iniciando Motor de Áudio para {historia_id}")
                
                genero = historia.genero_narrador or "masculino"
                texto_para_audio = historia.texto_narrado if historia.texto_narrado else historia.texto_original
                
                # Checa configuração de TTS
                from app.db.models import ConfiguracaoSistema
                result_config = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
                config = result_config.scalars().first()
                
                await add_log("Etapa 1: Sintetizando áudio de voz neural...")
                if config and config.usar_edge_tts:
                    await add_log("-> Usando provedor: Edge-TTS (Gratuito/Ilimitado)")
                    from app.services.edge_tts_service import gerar_audio_edge_tts
                    caminho_audio, custo_voz = await gerar_audio_edge_tts(texto_para_audio, genero, historia_id, historia.idioma)
                else:
                    await add_log("-> Usando provedor: ElevenLabs (Premium)")
                    caminho_audio, custo_voz = await gerar_audio_tts(texto_para_audio, genero, historia_id)
                    
                historia.custo_ia_voz = custo_voz
                await add_log(f"✔ Áudio de voz gerado com sucesso.")
                
                probe = ffmpeg.probe(caminho_audio)
                duracao_audio = float(probe['format']['duration'])
                historia.duracao_audio_segundos = int(duracao_audio)
                
                if duracao_audio < 65:
                    if historia.parent_id is not None:
                        await add_log(f"⚠ Áudio da série muito curto ({duracao_audio:.1f}s). Retornando para aprovação humana para esticar.")
                        historia.status = StatusHistoria.AGUARDANDO_APROVACAO
                    else:
                        await add_log(f"⚠ Áudio muito curto ({duracao_audio:.1f}s). Rejeitado.")
                        historia.status = StatusHistoria.REPROVADO_CURTO
                    await db.commit()
                    return
                elif 65 <= duracao_audio <= 89:
                    await add_log(f"⚠ Áudio tem duração perigosa para Shorts ({duracao_audio:.1f}s). Aguardando aprovação humana.")
                    historia.status = StatusHistoria.APROVACAO_HUMANA_TEMPO
                    await db.commit()
                    return
                    
                await add_log("Etapa 2: Transcrição inteligente (Whisper)...")
                await add_log("-> Carregando modelo base na CPU e extraindo tempo de cada palavra.")
                caminho_json, _ = await asyncio.to_thread(transcrever_audio_local, caminho_audio, historia_id)
                
                if historia.parent_id is not None:
                    historia.status = StatusHistoria.LIBERADO_RENDERIZACAO
                    historia.velocidade_video = 1.3
                    await add_log("✔ Áudio pronto! Enviando automaticamente para renderização (1.3x) por ser tradução.")
                    await db.commit()
                    # Chama a própria task de renderização para a fila
                    renderizar_video_task.apply_async(args=[str(historia_id), "1.3"], queue='media_tasks')
                else:
                    historia.status = StatusHistoria.AUDIO_PRONTO
                    historia.data_fim_audio = datetime.utcnow()
                    await add_log("✔ Transcrição concluída! Áudio e legendas prontos.")
                    await db.commit()
            except Exception as e:
                await add_log(f"❌ Erro Crítico no Áudio: {e}")
                historia.status = StatusHistoria.ERRO_FATAL_AUDIO
                from datetime import datetime
                historia.data_fim_audio = datetime.utcnow()
                historia.log_erro = str(e)
                await db.commit()
                
    finally:
        r.delete("processing_audio_id")


@shared_task(bind=True, max_retries=1)
def renderizar_video_task(self, historia_id: str, velocidade: str = "1.0"):
    asyncio.run(processar_video(historia_id, velocidade))

async def processar_video(historia_id: str, velocidade: str = "1.0"):
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    r.set("processing_video_id", historia_id)
    try:
        await engine.dispose()
        async with AsyncSessionLocal() as db:
            result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == uuid.UUID(historia_id)))
            historia = result.scalars().first()
            
            async def add_log(msg: str):
                from datetime import datetime
                now = datetime.now().strftime("%d/%m %H:%M:%S")
                log_line = f"[{now}] {msg}\n"
                logger.info(msg)
                if getattr(historia, 'log_processamento', None):
                    historia.log_processamento += log_line
                else:
                    historia.log_processamento = log_line
                await db.commit()
                
            caminho_audio = f"/app/output/{historia_id}_temp_audio.mp3"
            caminho_json = f"/app/output/{historia_id}_temp_subs.json"
            caminho_ass = f"/app/output/{historia_id}_temp.ass"
            
            try:
                await add_log(f"Iniciando Renderização para {historia_id} com velocidade {velocidade}x")
                
                with open(caminho_json, 'r', encoding='utf-8') as f:
                    json_whisper = json.load(f)
                    
                duracao_audio = float(historia.duracao_audio_segundos)
                
                # Velocidade selecionada na UI (ex: 1.15)
                atempo_val = float(velocidade)
                
                # Override de segurança se o áudio original for muito longo, acelera mais se necessário
                if duracao_audio > 150:
                    calc = duracao_audio / 150.0
                    if calc > atempo_val:
                        atempo_val = calc
                    if atempo_val > 1.3: atempo_val = 1.3
                    
                saida_path = f"/app/output/BETA_{historia.id}_final.mp4"
                imagem_gancho_path = historia.caminho_imagem_gancho or "/app/assets/hooks/default.jpg"
                
                dir_backgrounds = "/app/assets/backgrounds"
                bg_files = [f for f in os.listdir(dir_backgrounds) if f.endswith(".mp4")]
                video_fundo_path = os.path.join(dir_backgrounds, random.choice(bg_files))

                await add_log(f"-> Background selecionado: {os.path.basename(video_fundo_path)}")

                # Pega duração do background para aleatorizar o corte
                try:
                    bg_probe = ffmpeg.probe(video_fundo_path)
                    duracao_bg_total = float(bg_probe['format']['duration'])
                except:
                    duracao_bg_total = 600.0 # Chute de 10 minutos se falhar
                    
                duracao_final_necessaria = (duracao_audio / atempo_val) - 3.0
                if duracao_final_necessaria < 1.0: duracao_final_necessaria = 1.0
                
                # Escolhe um ponto inicial aleatório que ainda caiba a duração necessária
                max_start = duracao_bg_total - duracao_final_necessaria
                if max_start < 0: max_start = 0
                start_time_aleatorio = random.uniform(0, max_start)

                await add_log("Etapa 1: Juntando Fundo + Imagem da Capa + Áudio com Filtro Atempo...")
                erro_render = await asyncio.to_thread(
                    renderizar_video_complexo,
                    imagem_gancho_path=imagem_gancho_path,
                    video_fundo_path=video_fundo_path,
                    audio_path=caminho_audio,
                    saida_path=saida_path,
                    duracao_audio=duracao_audio,
                    atempo_val=atempo_val,
                    titulo_gancho=historia.titulo_gancho,
                    json_whisper=json_whisper,
                    historia_id=historia_id,
                    start_time_bg=start_time_aleatorio
                )
                
                if erro_render:
                    await add_log(f"❌ Erro na renderização do vídeo: {erro_render}")
                    historia.status = StatusHistoria.ERRO_FATAL_RENDERIZACAO
                    historia.log_erro = erro_render
                else:
                    await add_log("✔ Renderização concluída SUCESSO!")
                    historia.status = StatusHistoria.BETA_PRONTO
                    # Upload para o YouTube agora é estritamente manual pelo botão na UI
                    await add_log("-> Vídeo disponível no Acervo. Publicação no YouTube deve ser feita manualmente.")
                    
                await db.commit()
            except Exception as e:
                await add_log(f"❌ Erro Crítico na Renderização: {e}")
                historia.status = StatusHistoria.ERRO_FATAL_RENDERIZACAO
                historia.log_erro = str(e)
                await db.commit()
    finally:
        logger.info("Arquivos temporários (áudio, capa, vídeo) mantidos conforme solicitação do usuário.")
        r.delete("processing_video_id")

@shared_task(bind=True, max_retries=1)
def baixar_background_task(self, url: str):
    import yt_dlp
    import os
    import asyncio
    from app.db.models import VideoBackground
    from sqlalchemy import update
    from app.db.session import AsyncSessionLocal
    
    async def processar():
        logger.info(f"Iniciando download yt-dlp para {url}")
        os.makedirs('/app/assets/backgrounds', exist_ok=True)
        
        import redis
        r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
        
        def hook_progresso(d):
            if d['status'] == 'downloading':
                p = d.get('_percent_str', '0%').strip()
                import re
                p = re.sub(r'\x1b\[[0-9;]*m', '', p)
                r.setex(f"bg_progress_{url}", 3600, p)
            elif d['status'] == 'finished':
                r.setex(f"bg_progress_{url}", 3600, '100%')

        ydl_opts = {
            'format': 'bestvideo[ext=mp4][height<=1080]/bestvideo[height<=1080]',
            'outtmpl': '/app/assets/backgrounds/%(id)s.%(ext)s',
            'quiet': True,
            'no_warnings': True,
            'nocheckcertificate': True,
            'progress_hooks': [hook_progresso]
        }
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                titulo = info.get('title', 'Background YouTube')
                caminho = f"/app/assets/backgrounds/{info['id']}.mp4"
                
                async with AsyncSessionLocal() as db:
                    await db.execute(update(VideoBackground).where(VideoBackground.url_youtube == url).values(
                        status="PRONTO",
                        titulo=titulo,
                        caminho_arquivo=caminho
                    ))
                    await db.commit()
        except Exception as e:
            logger.error(f"Erro yt-dlp: {e}")
            async with AsyncSessionLocal() as db:
                await db.execute(update(VideoBackground).where(VideoBackground.url_youtube == url).values(status="ERRO"))
                await db.commit()
                
    asyncio.run(processar())

@shared_task(bind=True, max_retries=1)
def traduzir_historia_task(self, historia_id: str, idioma: str):
    import urllib.parse
    import httpx
    import time
    from datetime import datetime
    from app.services.ai_services import traduzir_roteiro
    
    async def processar():
        await engine.dispose()
        async with AsyncSessionLocal() as db:
            result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == uuid.UUID(historia_id)))
            historia = result.scalars().first()
            
            if not historia or historia.status != StatusHistoria.TRADUZINDO:
                logger.warning(f"Historia {historia_id} não está pronta para tradução.")
                return
            
            result_pai = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == historia.parent_id))
            historia_pai = result_pai.scalars().first()
            if not historia_pai:
                logger.error("História pai não encontrada.")
                historia.status = StatusHistoria.ERRO_FATAL_AUDIO
                historia.log_erro = "História pai não encontrada."
                await db.commit()
                return

            def add_log(msg: str):
                now = datetime.now().strftime("%d/%m %H:%M:%S")
                log_line = f"[{now}] {msg}\n"
                logger.info(msg)
                if historia.log_processamento:
                    historia.log_processamento += log_line
                else:
                    historia.log_processamento = log_line

            try:
                add_log(f"Iniciando tradução para '{idioma.upper()}'.")
                add_log("Etapa 1/4: Conectando à IA para traduzir roteiro e título...")
                await db.commit()
                
                traducao = await traduzir_roteiro(historia_pai.texto_narrado or historia_pai.texto_original, historia_pai.titulo_gancho, idioma)
                
                titulo_traduzido = traducao.get("titulo_traduzido", historia_pai.titulo_gancho)
                texto_traduzido = traducao.get("texto_traduzido", historia_pai.texto_narrado)
                
                historia.titulo_gancho = titulo_traduzido
                historia.texto_narrado = texto_traduzido
                
                # Agregar custo de tradução
                custo_trad_in = traducao.get("custo_input", 0.0)
                custo_trad_out = traducao.get("custo_output", 0.0)
                historia.custo_ia_texto = (historia.custo_ia_texto or 0.0) + custo_trad_in + custo_trad_out
                
                add_log("✔ Roteiro traduzido com sucesso.")
                await db.commit()
                
                add_log(f"Etapa 2/4: Reutilizando capa limpa do idioma original...")
                await db.commit()
                
                # Procura a versão _raw da capa pai
                capa_pai_raw = None
                if historia_pai.caminho_imagem_gancho:
                    # Tenta adivinhar o _raw a partir do caminho
                    caminho_base = historia_pai.caminho_imagem_gancho.rsplit('.', 1)[0]
                    ext = historia_pai.caminho_imagem_gancho.rsplit('.', 1)[1]
                    raw_path_guess = f"{caminho_base}_raw.{ext}"
                    if os.path.exists(raw_path_guess):
                        capa_pai_raw = raw_path_guess
                        
                import time
                import shutil
                os.makedirs('/app/assets/images', exist_ok=True)
                timestamp = int(time.time())
                file_path = f"/app/assets/images/{historia.id}_traducao_{timestamp}.jpg"
                
                if capa_pai_raw:
                    shutil.copy(capa_pai_raw, file_path)
                    add_log("Etapa 3/4: Tatuando o título traduzido na capa...")
                    await db.commit()
                    from app.services.media_services import tatuar_capa
                    tatuar_capa(file_path, titulo_traduzido)
                    historia.caminho_imagem_gancho = file_path
                    add_log("✔ Capa finalizada.")
                else:
                    add_log(f"⚠ Capa raw não encontrada. Gerando nova capa do zero...")
                    await db.commit()
                    # Usa o mesmo serviço que gera imagem do zero
                    import urllib.parse
                    import httpx
                    
                    prompt = f"A vertical youtube shorts thumbnail about: {titulo_traduzido}, hyper realistic, cinematic lighting, dramatic"
                    prompt_encoded = urllib.parse.quote(prompt)
                    import time
                    timestamp = int(time.time())
                    url_imagem = f"https://image.pollinations.ai/prompt/{prompt_encoded}?width=1080&height=1920&nologo=true&seed={timestamp}"
                    
                    async with httpx.AsyncClient(verify=False) as client:
                        resp = await client.get(url_imagem, timeout=40.0)
                        resp.raise_for_status()
                        with open(file_path, "wb") as f:
                            f.write(resp.content)
                            
                    add_log("Etapa 3/4: Tatuando o título traduzido na nova capa...")
                    await db.commit()
                    from app.services.media_services import tatuar_capa
                    tatuar_capa(file_path, titulo_traduzido)
                    historia.caminho_imagem_gancho = file_path
                    add_log("✔ Capa finalizada.")
                        
                historia.status = StatusHistoria.LIBERADO_AUDIO
                add_log("Etapa 4/4: Redirecionando para a esteira de Áudio (ElevenLabs).")
                await db.commit()
                
                from app.workers.celery_app import celery_app
                celery_app.send_task("app.workers.tasks_media.gerar_audio_task", args=[str(historia.id)], queue='media_tasks')
                
            except Exception as e:
                add_log(f"❌ ERRO CRÍTICO: {str(e)}")
                historia.status = StatusHistoria.ERRO_FATAL_AUDIO
                historia.log_erro = str(e)
                await db.commit()
                
    asyncio.run(processar())

@shared_task(bind=True, max_retries=1)
def publicar_youtube_task(self, historia_id: str):
    import asyncio
    import uuid
    import os
    from sqlalchemy.future import select
    from app.db.session import AsyncSessionLocal, engine
    from app.db.models import HistoriaReddit, StatusHistoria
    from app.services.youtube_service import fazer_upload_video
    
    async def processar():
        await engine.dispose()
        async with AsyncSessionLocal() as db:
            result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == uuid.UUID(historia_id)))
            historia = result.scalars().first()
            if not historia: return
            
            try:
                video_path = f"/app/output/BETA_{historia.id}_final.mp4"
                
                if not os.path.exists(video_path):
                    logger.error(f"Vídeo final não encontrado para publicação: {video_path}")
                    return

                video_id = await fazer_upload_video(historia, db, video_path=video_path)
                
                from datetime import datetime
                historia.status = StatusHistoria.PUBLICADO
                historia.url_video_publicado = f"https://youtube.com/shorts/{video_id}"
                historia.data_publicacao = datetime.utcnow()
                await db.commit()
                
            except Exception as e:
                historia.log_erro = f"Erro no YouTube Upload: {str(e)}"
                await db.commit()
                
    asyncio.run(processar())

@shared_task(bind=True, max_retries=1)
def publicar_serie_youtube_task(self, parent_id: str):
    import asyncio
    import uuid
    import os
    import redis
    from sqlalchemy.future import select
    from app.db.session import AsyncSessionLocal, engine
    from app.db.models import HistoriaReddit, StatusHistoria
    from app.services.youtube_service import fazer_upload_video
    
    async def processar():
        r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
        try:
            await engine.dispose()
            async with AsyncSessionLocal() as db:
                result = await db.execute(
                    select(HistoriaReddit)
                    .where(HistoriaReddit.parent_id == uuid.UUID(parent_id))
                    .order_by(HistoriaReddit.parte_numero)
                )
                partes = result.scalars().all()
                if not partes: return
                
                from datetime import datetime
                for parte in partes:
                    if parte.status == StatusHistoria.PUBLICADO:
                        continue
                        
                    try:
                        video_path = f"/app/output/BETA_{parte.id}_final.mp4"
                        
                        if not os.path.exists(video_path):
                            logger.error(f"Vídeo da parte {parte.parte_numero} não encontrado: {video_path}")
                            parte.log_erro = "Vídeo final não encontrado."
                            await db.commit()
                            break # abort series
                            
                        video_id = await fazer_upload_video(parte, db, video_path=video_path)
                        
                        parte.status = StatusHistoria.PUBLICADO
                        parte.url_video_publicado = f"https://youtube.com/shorts/{video_id}"
                        parte.data_publicacao = datetime.utcnow()
                        parte.log_erro = None
                        await db.commit()
                        
                        # Wait a little bit to avoid Youtube API limits if publishing sequentially
                        await asyncio.sleep(5)
                        
                    except Exception as e:
                        parte.log_erro = f"Erro no YouTube Upload (Abortando a série): {str(e)}"
                        await db.commit()
                        break # Stop publishing subsequent parts
                        
        finally:
            r.srem("processing_saga_ids", parent_id)
                
    asyncio.run(processar())
