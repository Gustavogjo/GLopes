from celery import Celery
from celery.schedules import crontab
from app.core.config import settings

celery_app = Celery(
    "fabrica_videos",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=[
        "app.workers.tasks_io", 
        "app.workers.tasks_media", 
        "app.workers.tasks_beat"
    ]
)

celery_app.conf.update(
    task_routes={
        "app.workers.tasks_io.*": {"queue": "io_tasks"},
        "app.workers.tasks_media.*": {"queue": "media_tasks"},
        "app.workers.tasks_beat.*": {"queue": "io_tasks"}, # Executa tarefas de agendamento na fila IO
    },
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="America/Sao_Paulo",
    enable_utc=True,
    task_acks_late=True, # Garante que a task não seja perdida se o servidor reiniciar no meio
    worker_prefetch_multiplier=1, # Cada worker pega apenas 1 task por vez (evita travar a fila)
)

celery_app.conf.beat_schedule = {
    'minerar-reddit-diariamente': {
        'task': 'app.workers.tasks_io.minerar_reddit_task',
        'schedule': crontab(hour='12', minute='0'), # Exemplo: todo dia ao meio-dia
    },
    'inteligencia-youtube-6h': {
        'task': 'app.workers.tasks_beat.atualizar_engajamento_youtube_task',
        'schedule': crontab(hour='*/6', minute='0'), # A cada 6 horas
    },
    'estatisticas-canal-6h': {
        'task': 'app.workers.tasks_beat.atualizar_estatisticas_canal_task',
        'schedule': crontab(hour='*/6', minute='30'), # A cada 6 horas, defasado em 30 min
    },
    'garbage-collector-meia-noite': {
        'task': 'app.workers.tasks_beat.garbage_collector_cold_storage_task',
        'schedule': crontab(hour='0', minute='0'), # Meia-noite
    },
}
