import asyncio
import logging
from celery import shared_task
from sqlalchemy.future import select

from app.db.session import AsyncSessionLocal
from app.db.models import HistoriaReddit, StatusHistoria
from app.services.reddit_service import obter_submissions
from app.services.ai_services import (
    avaliar_historia_router,
    gerar_gancho_imagem_e_titulo
)

logger = logging.getLogger(__name__)

@shared_task(bind=True, max_retries=3)
def minerar_reddit_task(self):
    """
    Task executada pelo Celery Beat ou Manualmente.
    Opera a orquestração completa da Fase 2 de mineração de conteúdo e I/O.
    """
    asyncio.run(processar_mineracao())

async def processar_mineracao():
    from app.db.models import ConfiguracaoSistema
    async with AsyncSessionLocal() as db:
        # Pega a configuração
        result_config = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
        config = result_config.scalars().first()
        
        subs_list = ["RelatosDoReddit"]
        if config and config.subreddits_busca:
            subs_list = [s.strip() for s in config.subreddits_busca.split(",") if s.strip()]
            
        time_filters = ["day"]
        if config and hasattr(config, 'reddit_time_filters') and config.reddit_time_filters:
            time_filters = [t.strip() for t in config.reddit_time_filters.split(",") if t.strip()]

        # 1. Obter Submissions com filtro primário
        submissions, erros = obter_submissions(
            subreddits=subs_list,
            time_filters=time_filters,
            limit=50, 
            custom_cookie=config.reddit_cookie, 
            custom_user_agent=config.reddit_user_agent
        )
        
        from app.db.models import LogSistema
        if erros:
            for erro in erros:
                novo_log = LogSistema(tipo_tarefa="MINERACAO_REDDIT", sucesso=False, detalhes=erro)
                db.add(novo_log)
        else:
            msg_sucesso = f"Mineração concluída com sucesso em: {', '.join(subs_list)}. {len(submissions)} histórias coletadas."
            novo_log = LogSistema(tipo_tarefa="MINERACAO_REDDIT", sucesso=True, detalhes=msg_sucesso)
            db.add(novo_log)
            
        await db.commit()

        if not submissions:
            logger.info(f"Nenhuma submissão válida encontrada nos subreddits: {subs_list}")
            return

    async with AsyncSessionLocal() as db:
        for sub in submissions:
            id_post = sub["id"]
            
            # Anti-Duplicidade e Atualização de Métricas
            result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id_post_reddit == id_post))
            historia_existente = result.scalars().first()
            
            if historia_existente:
                # Atualiza as métricas de engajamento
                historia_existente.ups = sub.get("ups", historia_existente.ups)
                historia_existente.num_comments = sub.get("num_comments", historia_existente.num_comments)
                historia_existente.upvote_ratio = sub.get("upvote_ratio", historia_existente.upvote_ratio)
                
                # Atualiza os comentários caso tenha novos e a história esteja em fase inicial
                if historia_existente.status in [StatusHistoria.AGUARDANDO_APROVACAO, StatusHistoria.REVISAO_HUMANA]:
                    novos_comentarios = sub.get("comentarios_reddit", "")
                    if novos_comentarios and novos_comentarios != historia_existente.comentarios_reddit:
                        historia_existente.comentarios_reddit = novos_comentarios
                        logger.info(f"Comentários atualizados para a história {id_post}.")
                        
                await db.commit()
                logger.info(f"História {id_post} já existe. Métricas e comentários atualizados. Pulando inserção.")
                continue
                
            texto = sub["selftext"]
            titulo = sub["title"]
            
            logger.info(f"Processando história RAW: {id_post}")
            
            try:
                # Apenas persistência bruta (Fase 1)
                nova_historia = HistoriaReddit(
                    id_post_reddit=id_post,
                    subreddit=sub.get("subreddit"),
                    titulo_reddit=titulo,
                    texto_original=texto,
                    comentarios_reddit=sub.get("comentarios_reddit", ""),
                    ups=sub.get("ups", 0),
                    num_comments=sub.get("num_comments", 0),
                    upvote_ratio=sub.get("upvote_ratio", 0.0),
                    status=StatusHistoria.AGUARDANDO_APROVACAO,
                    custo_ia_texto=0.0
                )
                
                db.add(nova_historia)
                await db.commit()
                logger.info(f"História RAW {id_post} salva com sucesso para análise futura.")
                
            except Exception as e:
                logger.error(f"Erro fatal no salvamento da submissão {id_post}: {e}")
                await db.rollback()
                continue

@shared_task(bind=True, max_retries=3)
def task_publicar_video(self, historia_id: str):
    """
    Task de I/O para fazer upload do vídeo finalizado no YouTube.
    Executada pelo worker_io após a renderização ser concluída.
    """
    asyncio.run(processar_upload(historia_id))

async def processar_upload(historia_id: str):
    import uuid
    from datetime import datetime
    from app.services.youtube_service import fazer_upload_video
    
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == uuid.UUID(historia_id)))
        historia = result.scalars().first()
        
        if not historia or historia.status != StatusHistoria.BETA_PRONTO:
            logger.warning(f"Vídeo {historia_id} não encontrado ou não está pronto para upload.")
            return
            
        try:
            logger.info(f"Conectando à API do YouTube para envio do vídeo {historia_id}...")
            video_id = await fazer_upload_video(historia, db)
            
            # Sucesso
            historia.status = StatusHistoria.PUBLICADO
            historia.url_video_publicado = f"https://youtu.be/{video_id}"
            historia.data_publicacao = datetime.utcnow()
            await db.commit()
            
            logger.info(f"🔥 SUCESSO ABSOLUTO! Vídeo publicado: https://youtu.be/{video_id}")
            
        except Exception as e:
            logger.error(f"Erro ao publicar no YouTube: {e}")
            # Opcional: criar um status ERRO_PUBLICACAO ou jogar para falha
            await db.rollback()
            raise e

@shared_task(bind=True, max_retries=2)
def gerar_descricao_youtube_task(self, historia_id: str):
    """
    Task de I/O / AI para gerar a descrição do vídeo para o YouTube.
    Executada quando a história é enviada para Distribuição.
    """
    asyncio.run(processar_geracao_descricao(historia_id))

async def processar_geracao_descricao(historia_id: str):
    import uuid
    from app.services.ai_services import gerar_descricao_youtube
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == uuid.UUID(historia_id)))
        historia = result.scalars().first()
        
        if not historia:
            logger.warning(f"Vídeo {historia_id} não encontrado para gerar descrição.")
            return
            
        try:
            logger.info(f"Gerando descrição IA para o vídeo {historia_id}...")
            resultado_desc = await gerar_descricao_youtube(
                historia.texto_narrado or historia.texto_original, 
                historia.titulo_gancho or historia.titulo_reddit, 
                historia.idioma
            )
            historia.descricao_youtube = resultado_desc.get("descricao", "")
            historia.custo_ia_texto = (historia.custo_ia_texto or 0.0) + resultado_desc.get("custo_usd", 0.0)
            await db.commit()
            logger.info(f"Descrição gerada com sucesso para {historia_id}!")
        except Exception as e:
            logger.error(f"Erro ao gerar descrição YouTube em background: {e}")
            await db.rollback()

