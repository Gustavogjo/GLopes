import asyncio
import shutil
import zipfile
import os
from datetime import datetime, timedelta
from celery import shared_task
from sqlalchemy.future import select
from app.db.session import AsyncSessionLocal
from app.db.models import HistoriaReddit, StatusHistoria, EstatisticaCanal

@shared_task(bind=True)
def atualizar_estatisticas_canal_task(self):
    """
    Registra as estatísticas globais do canal no banco de dados.
    """
    asyncio.run(processar_estatisticas_canal())

async def processar_estatisticas_canal():
    from app.services.youtube_service import obter_estatisticas_canal
    import logging
    logger = logging.getLogger(__name__)
    
    async with AsyncSessionLocal() as db:
        try:
            stats_pt = await obter_estatisticas_canal(db, lang="pt")
            if stats_pt:
                nova_estatistica = EstatisticaCanal(
                    idioma="pt",
                    inscritos=stats_pt.get("inscritos", 0),
                    visualizacoes_totais=stats_pt.get("visualizacoes_totais", 0),
                    videos_totais=stats_pt.get("videos_totais", 0)
                )
                db.add(nova_estatistica)
                await db.commit()
                logger.info(f"Estatísticas do canal registradas: {stats_pt}")
        except Exception as e:
            logger.error(f"Erro ao registrar estatísticas do canal: {e}")

@shared_task(bind=True)
def atualizar_engajamento_youtube_task(self):
    """
    5.1 Inteligência de Negócio: YouTube Analytics
    """
    asyncio.run(processar_youtube_analytics())

async def processar_youtube_analytics():
    from app.services.youtube_service import obter_metricas_youtube
    async with AsyncSessionLocal() as db:
        # Busca todas publicadas que têm URL do YouTube
        result = await db.execute(
            select(HistoriaReddit)
            .where(HistoriaReddit.status == StatusHistoria.PUBLICADO)
            .where(HistoriaReddit.url_video_publicado != None)
        )
        historias = result.scalars().all()
        
        for h in historias:
            # Extrair ID do vídeo da URL
            # Ex: https://www.youtube.com/watch?v=VIDEO_ID ou https://youtu.be/VIDEO_ID ou https://www.youtube.com/shorts/VIDEO_ID
            video_id = None
            url = h.url_video_publicado
            
            if "watch?v=" in url:
                video_id = url.split("watch?v=")[1].split("&")[0]
            elif "youtu.be/" in url:
                video_id = url.split("youtu.be/")[1].split("?")[0]
            elif "shorts/" in url:
                video_id = url.split("shorts/")[1].split("?")[0]
                
            if video_id:
                views, likes, comments = await obter_metricas_youtube(video_id, h.idioma or "pt", db)
                
                h.visualizacoes_youtube = views
                h.likes_youtube = likes
                h.comentarios_youtube = comments
                
                if views > 0:
                    nota_raw = ((likes * 2) + (comments * 5)) / views
                    # Normaliza (exemplo arbitrário)
                    nota_normalizada = min(10.0, nota_raw * 100)
                    h.nota_engajamento_youtube = round(nota_normalizada, 2)
                
        await db.commit()

@shared_task(bind=True)
def garbage_collector_cold_storage_task(self):
    """
    5.2 Garbage Collector e Cold Storage (Transacional)
    """
    asyncio.run(processar_garbage_collection())

async def processar_garbage_collection():
    agora = datetime.utcnow()
    limite_expurgo = agora - timedelta(days=15)
    
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.status == StatusHistoria.PUBLICADO))
        historias = result.scalars().all()
        
        for h in historias:
            # 1. Compactar para /app/backups/ se recém publicado e ainda não processado
            if not h.data_publicacao:
                h.data_publicacao = agora # Atualiza data
                
                # Mock path
                ano, mes, dia = agora.strftime("%Y"), agora.strftime("%m"), agora.strftime("%d")
                dir_backup = f"/app/backups/{ano}/{mes}/{dia}"
                os.makedirs(dir_backup, exist_ok=True)
                
                zip_path = os.path.join(dir_backup, f"{dia}_{h.id}_video.zip")
                video_orig_path = f"/app/output/{h.id}_final.mp4"
                
                try:
                    # Transação segura de arquivo
                    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                        if os.path.exists(video_orig_path):
                            zipf.write(video_orig_path, arcname=os.path.basename(video_orig_path))
                            
                    # A exclusão física original ocorre apenas após confirmação
                    if os.path.exists(zip_path) and os.path.getsize(zip_path) > 0:
                        if os.path.exists(video_orig_path):
                            os.remove(video_orig_path)
                            
                except Exception as e:
                    h.log_erro = f"Falha no backup: {str(e)}"
            
            # 2. Expurgo Definitivo após 15 dias
            if h.data_publicacao and h.data_publicacao < limite_expurgo and not h.flag_exclusao_segura:
                h.flag_exclusao_segura = True
                
                # Deleta o zip
                ano, mes, dia = h.data_publicacao.strftime("%Y"), h.data_publicacao.strftime("%m"), h.data_publicacao.strftime("%d")
                zip_path = f"/app/backups/{ano}/{mes}/{dia}/{dia}_{h.id}_video.zip"
                
                if os.path.exists(zip_path):
                    os.remove(zip_path)
                        
        # 3. Limpeza de Histórias Brutas Ignoradas (RAW) há mais de 15 dias
        limite_ignorado = agora - timedelta(days=15)
        result_raw = await db.execute(
            select(HistoriaReddit)
            .where(HistoriaReddit.status == StatusHistoria.AGUARDANDO_APROVACAO)
            .where(HistoriaReddit.data_criacao < limite_ignorado)
        )
        historias_raw = result_raw.scalars().all()
        for h in historias_raw:
            await db.delete(h)
            
        await db.commit()
