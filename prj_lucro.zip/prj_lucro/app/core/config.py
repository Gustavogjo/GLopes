import os
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    PROJECT_NAME: str = "Fabrica Automatizada de Videos"
    
    POSTGRES_USER: str = "admin"
    POSTGRES_PASSWORD: str = "senha_forte"
    POSTGRES_DB: str = "fabrica_videos_db"
    
    DATABASE_URL_ASYNC: str = "postgresql+asyncpg://admin:senha_forte@localhost:5432/fabrica_videos_db"
    DATABASE_URL_SYNC: str = "postgresql://admin:senha_forte@localhost:5432/fabrica_videos_db"
    
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = REDIS_URL
    CELERY_RESULT_BACKEND: str = REDIS_URL
    
    REDDIT_CLIENT_ID: str = ""
    REDDIT_CLIENT_SECRET: str = ""
    REDDIT_USER_AGENT: str = "fabrica_videos_bot 1.0"
    
    OPENAI_API_KEY: str = ""
    GEMINI_API_KEY: str = ""
    ANTHROPIC_API_KEY: str = ""
    ELEVENLABS_API_KEY: str = ""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

settings = Settings()
