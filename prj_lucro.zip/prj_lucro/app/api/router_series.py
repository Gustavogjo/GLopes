import uuid
from fastapi import APIRouter, Depends, HTTPException, Request, Body, BackgroundTasks, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import Dict, Any, List

from app.db.session import get_db, AsyncSessionLocal
from app.db.models import HistoriaReddit, StatusHistoria
from app.api.router_ui import get_menu_badges
from fastapi.templating import Jinja2Templates
templates = Jinja2Templates(directory="app/templates")
from app.services.ai_services import dividir_historia_em_serie

router_series = APIRouter()

async def _processar_divisao_background(id_historia: uuid.UUID, partes: int):
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id_historia))
        historia_mae = result.scalars().first()
        
        if not historia_mae:
            return
            
        try:
            # Chama a IA para fatiar
            json_divisao = await dividir_historia_em_serie(historia_mae.texto_original, partes)
            
            partes_geradas = json_divisao.get("partes", [])
            num_partes_geradas = len(partes_geradas)
            
            if num_partes_geradas == 0:
                historia_mae.status = StatusHistoria.AGUARDANDO_APROVACAO
                await db.commit()
                return
                
            # Cria as filhas
            for part_info in partes_geradas:
                numero = part_info.get("parte")
                texto_roteiro = part_info.get("texto")
                
                nova_historia = HistoriaReddit(
                    id_post_reddit=f"{historia_mae.id_post_reddit}_P{numero}",
                    subreddit=historia_mae.subreddit,
                    titulo_reddit=f"{historia_mae.titulo_reddit}",
                    texto_original=historia_mae.texto_original,
                    texto_narrado=texto_roteiro,
                    status=StatusHistoria.AGUARDANDO_APROVACAO,
                    parent_id=historia_mae.id,
                    parte_numero=numero,
                    idioma=historia_mae.idioma,
                    ups=historia_mae.ups,
                    num_comments=historia_mae.num_comments
                )
                db.add(nova_historia)
                
            # Mantém a mãe como dividida
            await db.commit()
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            # Reverte status se der erro
            historia_mae.status = StatusHistoria.AGUARDANDO_APROVACAO
            await db.commit()

@router_series.post("/api/dividir-historia/{id}")
async def api_dividir_historia(id: uuid.UUID, background_tasks: BackgroundTasks, body: dict = Body(...), db: AsyncSession = Depends(get_db)):
    partes = body.get("partes", 2)
    
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia_mae = result.scalars().first()
    
    if not historia_mae:
        raise HTTPException(status_code=404, detail="História original não encontrada.")
        
    # Esconde da curadoria imediatamente
    historia_mae.status = StatusHistoria.DIVIDIDA_EM_SERIE
    await db.commit()
    
    background_tasks.add_task(_processar_divisao_background, id, partes)
    
    return {"status": "ok", "message": f"Divisão em {partes} partes iniciada em segundo plano. Verifique a aba Séries em breve."}

@router_series.get("/series", response_class=HTMLResponse)
async def series_page(request: Request, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    # Buscar todas as histórias filhas agrupadas por parent_id
    result = await db.execute(
        select(HistoriaReddit)
        .where(HistoriaReddit.parte_numero.isnot(None))
        .order_by(HistoriaReddit.parent_id, HistoriaReddit.parte_numero)
    )
    filhas = result.scalars().all()
    
    # Buscar as mães correspondentes
    parent_ids = list(set([f.parent_id for f in filhas if f.parent_id]))
    
    maes_result = await db.execute(
        select(HistoriaReddit)
        .where(HistoriaReddit.id.in_(parent_ids))
    )
    maes_list = maes_result.scalars().all()
    maes_dict = {m.id: m for m in maes_list}
    
    # Agrupar as sagas
    sagas = {}
    for f in filhas:
        if f.texto_narrado:
            f.num_chars_calc = len(f.texto_narrado)
            f.num_palavras_calc = len(f.texto_narrado.split())
            minutes = (f.num_palavras_calc / 150.0) / 1.3
            total_seconds = int(minutes * 60)
            f.tempo_estimado_calc = f"{total_seconds // 60}m{total_seconds % 60:02d}s"
        else:
            f.num_chars_calc = 0
            f.num_palavras_calc = 0
            f.tempo_estimado_calc = "--"

        if f.parent_id not in sagas:
            sagas[f.parent_id] = {
                "mae": maes_dict.get(f.parent_id),
                "partes": []
            }
        sagas[f.parent_id]["partes"].append(f)
        
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    processing_saga_ids = r.smembers("processing_saga_ids") or set()

    return templates.TemplateResponse(
        request=request,
        name="series.html",
        context={
            "sagas": list(sagas.values()),
            "badges": badges,
            "processing_saga_ids": list(processing_saga_ids)
        }
    )

from pydantic import BaseModel

class RoteiroUpdate(BaseModel):
    texto_narrado: str

@router_series.post("/api/series/parte/{id}/salvar")
async def salvar_roteiro_parte(id: uuid.UUID, data: RoteiroUpdate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail="Parte não encontrada.")
        
    historia.texto_narrado = data.texto_narrado
    await db.commit()
    return {"status": "ok"}

@router_series.post("/api/series/parte/{id}/refazer")
async def refazer_roteiro_parte(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail="Parte não encontrada.")
        
    historia.status = StatusHistoria.AGUARDANDO_APROVACAO
    historia.caminho_imagem_gancho = None
    historia.titulo_gancho = None
    await db.commit()
    
    return RedirectResponse(url="/series", status_code=303)

from fastapi import BackgroundTasks
from app.db.session import AsyncSessionLocal
import redis

async def processar_saga_background(parent_id: uuid.UUID):
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(HistoriaReddit)
            .where(HistoriaReddit.parent_id == parent_id)
            .order_by(HistoriaReddit.parte_numero)
        )
        partes = result.scalars().all()
        
        for historia in partes:
            if historia.status not in [StatusHistoria.AGUARDANDO_APROVACAO, StatusHistoria.REPROVADO_CURTO, StatusHistoria.REPROVADO_PO]:
                r.srem("processing_saga_ids", str(historia.id))
                continue
                
            if not historia.caminho_imagem_gancho:
                from app.services.ai_services import gerar_gancho_imagem_e_titulo
                titulo_base = historia.titulo_reddit
                if f"Parte {historia.parte_numero}" not in titulo_base:
                    titulo_base = f"{titulo_base} [Parte {historia.parte_numero}]"
                    
                gancho = await gerar_gancho_imagem_e_titulo(
                    texto=historia.texto_narrado, 
                    id_post_reddit=historia.id_post_reddit, 
                    titulo_existente=titulo_base
                )
                historia.titulo_gancho = gancho.get('titulo_gancho')
                historia.caminho_imagem_gancho = gancho.get('caminho_imagem_gancho')
                
            historia.status = StatusHistoria.LIBERADO_AUDIO
            r.srem("processing_saga_ids", str(historia.id))
            
        await db.commit()
        
        # Aciona task de áudio para cada parte
        from app.workers.tasks_media import gerar_audio_task
        for historia in partes:
            if historia.status == StatusHistoria.LIBERADO_AUDIO:
                gerar_audio_task.apply_async(args=[str(historia.id)], queue='media_tasks')
            
    # Ao terminar a saga inteira, tira o parent_id da lista de processing_saga
    r.srem("processing_saga_ids", str(parent_id))


@router_series.delete("/api/series/saga/{parent_id}/resetar")
async def resetar_saga(parent_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    """
    Remove todas as partes criadas para uma saga e volta a história original para a Curadoria.
    """
    # 1. Buscar a história mãe
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == parent_id))
    historia_mae = result.scalars().first()
    if not historia_mae:
        raise HTTPException(status_code=404, detail="Saga não encontrada.")
        
    # 2. Buscar todas as partes
    result_partes = await db.execute(select(HistoriaReddit).where(HistoriaReddit.parent_id == parent_id))
    partes = result_partes.scalars().all()
    
    # 3. Deletar arquivos físicos das partes
    import os
    for parte in partes:
        # Remover imagem
        if parte.caminho_imagem_gancho and os.path.exists(parte.caminho_imagem_gancho):
            try: os.remove(parte.caminho_imagem_gancho)
            except: pass
            
        # Remover áudio
        audio_path = f"/app/output/{parte.id}.mp3"
        if os.path.exists(audio_path):
            try: os.remove(audio_path)
            except: pass
            
        # Remover vídeo
        video_path = f"/app/output/{parte.id}_final.mp4"
        if os.path.exists(video_path):
            try: os.remove(video_path)
            except: pass
            
        # Remover legenda (JSON)
        json_path = f"/app/output/{parte.id}.json"
        if os.path.exists(json_path):
            try: os.remove(json_path)
            except: pass
            
        # 4. Deletar do banco
        await db.delete(parte)
        
    # 5. Voltar mãe para curadoria
    historia_mae.status = StatusHistoria.REVISAO_HUMANA
    await db.commit()
    
    return {"status": "ok", "message": "Saga resetada e movida para Curadoria."}


@router_series.post("/api/series/saga/{parent_id}/aprovar")
async def aprovar_roteiro_saga(parent_id: uuid.UUID, background_tasks: BackgroundTasks, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(HistoriaReddit)
        .where(HistoriaReddit.parent_id == parent_id)
    )
    partes = result.scalars().all()
    if not partes:
        raise HTTPException(status_code=404, detail="Nenhuma parte encontrada para essa saga.")
        
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    r.sadd("processing_saga_ids", str(parent_id))
    for p in partes:
        r.sadd("processing_saga_ids", str(p.id))
        
    background_tasks.add_task(processar_saga_background, parent_id)
    
    return {"status": "ok", "message": "Processamento iniciado em background"}


@router_series.post("/api/series/saga/{parent_id}/distribuir")
async def distribuir_saga(parent_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(HistoriaReddit)
        .where(HistoriaReddit.parent_id == parent_id)
        .where(HistoriaReddit.status.in_([StatusHistoria.BETA_PRONTO]))
    )
    partes = result.scalars().all()
    if not partes:
        # If no parts in BETA_PRONTO, maybe they are already in DISTRIBUICAO, so just redirect
        return RedirectResponse(url="/distribuicao", status_code=303)
        
    from app.workers.celery_app import celery_app
    for p in partes:
        p.status = StatusHistoria.DISTRIBUICAO
        if not p.descricao_youtube:
            celery_app.send_task("app.workers.tasks_io.gerar_descricao_youtube_task", args=[str(p.id)], queue='io_tasks')
        
    await db.commit()
    
    return RedirectResponse(url="/distribuicao", status_code=303)

@router_series.post("/api/series/saga/{parent_id}/desfazer-publicacao")
async def desfazer_publicacao_saga(parent_id: uuid.UUID, request: Request, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(HistoriaReddit)
        .where(HistoriaReddit.parent_id == parent_id)
        .where(HistoriaReddit.status == StatusHistoria.PUBLICADO)
    )
    partes = result.scalars().all()
    
    for historia in partes:
        historia.status = StatusHistoria.DISTRIBUICAO
        historia.url_video_publicado = None
        historia.data_publicacao = None
        historia.visualizacoes_youtube = 0
        historia.comentarios_youtube = 0
        historia.likes_youtube = 0
        
    await db.commit()
    
    referer = request.headers.get("referer", "/distribuicao")
    return RedirectResponse(url=referer, status_code=status.HTTP_303_SEE_OTHER)
