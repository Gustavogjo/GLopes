from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.db.session import get_db
from app.db.models import HistoriaReddit, StatusHistoria
from pydantic import BaseModel, ConfigDict
from typing import List, Optional
import uuid
import json

router = APIRouter(prefix="/historias", tags=["historias"])

class HistoriaSchema(BaseModel):
    id: uuid.UUID
    titulo_reddit: str
    status: StatusHistoria
    nota_media: Optional[float]
    
    model_config = ConfigDict(from_attributes=True)

@router.get("/", response_model=List[HistoriaSchema])
async def listar_historias(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit))
    return result.scalars().all()

@router.post("/{id}/aprovar-producao")
async def aprovar_producao(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail="História não encontrada")
    
    historia.status = StatusHistoria.LIBERADO_PRODUCAO
    await db.commit()
    
    from app.workers.tasks_media import gerar_midia_task
    gerar_midia_task.delay(str(historia.id))
    
    return {"message": "História enviada para fila de produção de mídia."}

@router.post("/{id}/aprovar-beta")
async def aprovar_beta(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail="História não encontrada")
        
    from app.workers.tasks_io import traduzir_e_renderizar_multilingue_task
    traduzir_e_renderizar_multilingue_task.delay(str(id))
    
    return {"message": "Enviado para tradução e renderização multilingue."}

@router.get("/fila")
async def status_fila():
    from app.workers.celery_app import celery_app
    i = celery_app.control.inspect()
    return {
        "active": i.active(),
        "scheduled": i.scheduled(),
        "reserved": i.reserved()
    }

@router.get("/player", response_class=HTMLResponse)
async def player_html():
    return """
    <html>
        <head>
            <title>Player de Vídeo Gerado</title>
            <style>
                body { background-color: #121212; color: white; font-family: sans-serif; text-align: center; }
                video { max-height: 80vh; border: 2px solid #333; border-radius: 10px; }
            </style>
        </head>
        <body>
            <h1>Fábrica Automatizada - Shorts</h1>
            <video controls>
                <source src="/static/output/exemplo.mp4" type="video/mp4">
                Seu navegador não suporta o elemento de vídeo.
            </video>
        </body>
    </html>
    """
