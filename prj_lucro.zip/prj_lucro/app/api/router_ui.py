import asyncio
import os
from datetime import datetime, timedelta
from fastapi import APIRouter, Request, Depends, HTTPException, status, File, UploadFile, Form, BackgroundTasks
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import desc, asc, func

from app.db.session import get_db
from app.db.models import HistoriaReddit, StatusHistoria, ConfiguracaoSistema
import uuid

router_ui = APIRouter(tags=["UI"])
templates = Jinja2Templates(directory="app/templates")

@router_ui.get("/api/teste-reddit")
async def teste_reddit_endpoint(db: AsyncSession = Depends(get_db)):
    from app.services.reddit_service import testar_conexao_reddit
    from app.db.models import ConfiguracaoSistema
    
    result = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
    config = result.scalars().first()
    
    subs_list = ["RelatosDoReddit"]
    if config and config.subreddits_busca:
        subs_list = [s.strip() for s in config.subreddits_busca.split(",") if s.strip()]

    # Rodamos numa thread separada pois é sincrono
    import asyncio
    loop = asyncio.get_event_loop()
    resultados = await loop.run_in_executor(None, testar_conexao_reddit, subs_list, 50, config.reddit_cookie, config.reddit_user_agent)
    return {"status": "ok", "detalhes": resultados}

@router_ui.post("/api/mineracao/forcar")
async def forcar_mineracao():
    from app.workers.tasks_io import minerar_reddit_task
    # Dispara a task de forma assíncrona para o worker do Celery
    minerar_reddit_task.apply_async(queue='io_tasks')
    return {"status": "ok", "message": "Mineração enviada para fila do robô em background."}


async def get_menu_badges(db: AsyncSession = Depends(get_db)):
    from sqlalchemy import func
    
    # Conta todos os itens para os badges (incluindo traduções)
    counts_all = await db.execute(
        select(HistoriaReddit.status, func.count(HistoriaReddit.id))
        .group_by(HistoriaReddit.status)
    )
    dict_all = dict(counts_all.all())
    
    # Conta apenas itens pai (sem tradução)
    counts_pai = await db.execute(
        select(HistoriaReddit.status, func.count(HistoriaReddit.id))
        .where(HistoriaReddit.parent_id == None)
        .group_by(HistoriaReddit.status)
    )
    dict_pai = dict(counts_pai.all())
    
    def get_count_all(statuses):
        return sum(dict_all.get(s, 0) for s in statuses)
        
    def get_count_pai(statuses):
        return sum(dict_pai.get(s, 0) for s in statuses)
        
    return {
        'inbox': get_count_pai([StatusHistoria.AGUARDANDO_APROVACAO]),
        'curadoria': get_count_pai([StatusHistoria.REVISAO_HUMANA]),
        'montagem_audio': get_count_all([StatusHistoria.LIBERADO_AUDIO, StatusHistoria.AUDIO_PRONTO, StatusHistoria.ERRO_FATAL_AUDIO]),
        'montagem_video': get_count_all([StatusHistoria.LIBERADO_PRODUCAO, StatusHistoria.LIBERADO_RENDERIZACAO, StatusHistoria.ERRO_FATAL_RENDERIZACAO]),
        'acervo': get_count_all([StatusHistoria.BETA_PRONTO]),
        'internacionalizacao': get_count_pai([StatusHistoria.INTERNACIONALIZACAO]),
        'distribuicao': get_count_all([StatusHistoria.DISTRIBUICAO]),
        'series': get_count_all([StatusHistoria.DIVIDIDA_EM_SERIE]),
        'rejeitados': get_count_pai([StatusHistoria.REPROVADO_CURTO, StatusHistoria.REPROVADO_NOTA, StatusHistoria.REPROVADO_PO])
    }

@router_ui.get("/api/menu/badges")
async def api_get_menu_badges(badges: dict = Depends(get_menu_badges)):
    return badges

@router_ui.get("/", response_class=HTMLResponse)
async def dashboard_page(request: Request, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    from app.db.models import EstatisticaCanal
    from sqlalchemy import select, desc
    import json
    
    # Busca o histórico do canal (últimos 30 dias para o gráfico)
    result = await db.execute(select(EstatisticaCanal).order_by(desc(EstatisticaCanal.data_coleta)).limit(30))
    historico = result.scalars().all()
    
    historico_json = []
    inscritos_atual = 0
    visualizacoes_totais = 0
    
    if historico:
        inscritos_atual = historico[0].inscritos
        visualizacoes_totais = historico[0].visualizacoes_totais
        # Inverte para o gráfico (cronológico)
        for h in reversed(historico):
            historico_json.append({
                "data": h.data_coleta.strftime("%d/%m %H:%M"),
                "inscritos": h.inscritos,
                "visualizacoes": h.visualizacoes_totais
            })
            
    # Estatísticas avançadas (filas e processamento)
    import redis
    from sqlalchemy import func
    from app.db.models import StatusHistoria, HistoriaReddit
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    
    processing_ia_ids = r.smembers("processing_ia_ids") or set()
    inbox_processing = 0
    curadoria_processing_ia = 0
    
    if processing_ia_ids:
        # Convert set of strings to list of UUIDs
        import uuid
        valid_ids = []
        for pid in processing_ia_ids:
            try:
                valid_ids.append(uuid.UUID(pid))
            except:
                pass
        
        if valid_ids:
            proc_result = await db.execute(select(HistoriaReddit.status).where(HistoriaReddit.id.in_(valid_ids)))
            for (status,) in proc_result:
                if status == StatusHistoria.AGUARDANDO_APROVACAO:
                    inbox_processing += 1
                elif status == StatusHistoria.REVISAO_HUMANA:
                    curadoria_processing_ia += 1

    curadoria_processing_saga = len(r.smembers("processing_saga_ids") or set())
    curadoria_processing = curadoria_processing_ia + curadoria_processing_saga
    
    audio_processing = 1 if r.get("processing_audio_id") else 0
    video_processing = 1 if r.get("processing_video_id") else 0
    
    # Conta fila de áudio
    result_audio = await db.execute(select(func.count(HistoriaReddit.id)).where(HistoriaReddit.status == StatusHistoria.LIBERADO_AUDIO))
    audio_queue = result_audio.scalar() or 0
    
    # Conta fila de vídeo
    result_video = await db.execute(select(func.count(HistoriaReddit.id)).where(HistoriaReddit.status.in_([StatusHistoria.LIBERADO_PRODUCAO, StatusHistoria.LIBERADO_RENDERIZACAO])))
    video_queue = result_video.scalar() or 0
            
    return templates.TemplateResponse(request=request, name="dashboard.html", context={
        "badges": badges,
        "inscritos_atual": inscritos_atual,
        "visualizacoes_totais": visualizacoes_totais,
        "historico_json": json.dumps(historico_json),
        "inbox_processing": inbox_processing,
        "curadoria_processing": curadoria_processing,
        "audio_processing": audio_processing,
        "video_processing": video_processing,
        "audio_queue": audio_queue,
        "video_queue": video_queue
    })

from pydantic import BaseModel
from typing import List, Optional

class AnalisarLoteRequest(BaseModel):
    ids: List[uuid.UUID]

@router_ui.get("/inbox", response_class=HTMLResponse)
async def inbox_page(request: Request, sort: Optional[str] = None, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    query = select(HistoriaReddit).where(HistoriaReddit.status == StatusHistoria.AGUARDANDO_APROVACAO)
    
    if sort == "engajamento":
        query = query.order_by(desc(HistoriaReddit.ups + HistoriaReddit.num_comments))
    elif sort == "tamanho_maior":
        query = query.order_by(desc(func.length(HistoriaReddit.texto_original)))
    elif sort == "tamanho_menor":
        query = query.order_by(asc(func.length(HistoriaReddit.texto_original)))
    elif sort == "antigos":
        query = query.order_by(asc(HistoriaReddit.data_criacao))
    else:
        query = query.order_by(desc(HistoriaReddit.data_criacao))
        
    result = await db.execute(query)
    historias = result.scalars().all()
    
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    processing_ia_ids = r.smembers("processing_ia_ids") or set()
    
    # Ordena as histórias para que as que estão em processamento apareçam no topo, mantendo a ordem secundária
    historias.sort(key=lambda x: str(x.id) not in processing_ia_ids)
    
    return templates.TemplateResponse(request=request, name="inbox.html", context={"historias": historias, "badges": badges, "sort": sort, "processing_ia_ids": processing_ia_ids})

async def processar_lote_background(ids: list):
    import redis
    import asyncio
    from app.db.session import AsyncSessionLocal
    from app.services.ai_services import avaliar_historia_router, gerar_gancho_imagem_e_titulo
    
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    semaphore = asyncio.Semaphore(1)
    
    async def process_single(hid):
        async with semaphore:
            async with AsyncSessionLocal() as session:
                result = await session.execute(select(HistoriaReddit).where(HistoriaReddit.id == hid))
                historia = result.scalars().first()
                if historia and historia.status in (StatusHistoria.AGUARDANDO_APROVACAO, StatusHistoria.REVISAO_HUMANA):
                    try:
                        res = await avaliar_historia_router(historia.texto_original)
                        historia.texto_narrado = res.get('texto_reescrito')
                        historia.genero_narrador = res.get('genero_narrador')
                        historia.justificativa_ia = res.get('justificativa')
                        
                        nota = res.get('nota')
                        if nota is not None:
                            try:
                                historia.nota_gemini = float(nota)
                                historia.nota_media = historia.nota_gemini
                            except ValueError:
                                pass
                                
                        nota_viral = res.get('nota_viral')
                        if nota_viral is not None:
                            try:
                                historia.nota_viral = float(nota_viral)
                            except ValueError:
                                pass
                        if historia.nota_gemini is None:
                            historia.status = StatusHistoria.REVISAO_HUMANA
                            historia.data_analise_ia = (datetime.utcnow() - timedelta(hours=3))
                        elif historia.nota_gemini >= 7:
                            historia.status = StatusHistoria.REVISAO_HUMANA
                            historia.data_analise_ia = (datetime.utcnow() - timedelta(hours=3))
                            texto_base = historia.texto_narrado if historia.texto_narrado else historia.texto_original
                            gancho = await gerar_gancho_imagem_e_titulo(texto_base, historia.id_post_reddit)
                            historia.titulo_gancho = gancho.get('titulo_gancho')
                            historia.caminho_imagem_gancho = gancho.get('caminho_imagem_gancho')
                            historia.custo_ia_texto = (historia.custo_ia_texto or 0) + gancho.get('custo_ia_texto', 0.0)
                        else:
                            historia.status = StatusHistoria.REPROVADO_NOTA
                            
                        await session.commit()
                    except Exception as e:
                        print(f"Erro analisando lote {hid}: {e}")
                    finally:
                        r.srem("processing_ia_ids", str(hid))
                else:
                    r.srem("processing_ia_ids", str(hid))
                    
    await asyncio.gather(*(process_single(hid) for hid in ids))

@router_ui.post("/inbox/analisar-lote")
async def analisar_lote(request: AnalisarLoteRequest, background_tasks: BackgroundTasks, db: AsyncSession = Depends(get_db)):
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    for hid in request.ids:
        r.sadd("processing_ia_ids", str(hid))
        
    background_tasks.add_task(processar_lote_background, request.ids)
    return {"status": "ok", "enviados": len(request.ids)}

@router_ui.get("/api/inbox/processing-ids")
async def get_processing_ia_ids():
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    ids = r.smembers("processing_ia_ids") or set()
    saga_ids = r.smembers("processing_saga_ids") or set()
    return {"processing_ia_ids": list(ids), "processing_saga_ids": list(saga_ids)}

@router_ui.get("/api/lote/status")
async def get_lote_status(ids: str, db: AsyncSession = Depends(get_db)):
    """Recebe uma string de ids separados por vírgula e retorna um dict {id: status}"""
    if not ids:
        return {}
    lista_ids = [uuid.UUID(i.strip()) for i in ids.split(',') if i.strip()]
    if not lista_ids:
        return {}
    
    result = await db.execute(select(HistoriaReddit.id, HistoriaReddit.status).where(HistoriaReddit.id.in_(lista_ids)))
    historias = result.all()
    return {str(h.id): h.status.value for h in historias}

@router_ui.post("/inbox/descartar-lote")
async def descartar_lote(request: AnalisarLoteRequest, db: AsyncSession = Depends(get_db)):
    from datetime import datetime
    count = 0
    for hid in request.ids:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == hid))
        historia = result.scalars().first()
        if historia and historia.status == StatusHistoria.AGUARDANDO_APROVACAO:
            historia.status = StatusHistoria.REPROVADO_PO
            count += 1
            
    await db.commit()
    return {"status": "ok", "descartados": count}

@router_ui.get("/curadoria", response_class=HTMLResponse)
async def curadoria_page(request: Request, sort: Optional[str] = "nota", db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    query = select(HistoriaReddit).where(HistoriaReddit.status == StatusHistoria.REVISAO_HUMANA)
    
    if sort == "engajamento":
        query = query.order_by(desc(HistoriaReddit.ups + HistoriaReddit.num_comments))
    elif sort == "titulo":
        query = query.order_by(HistoriaReddit.titulo_gancho.asc())
    elif sort == "nota_asc":
        query = query.order_by(HistoriaReddit.nota_media.asc())
    elif sort == "data_ia":
        query = query.order_by(desc(HistoriaReddit.data_analise_ia))
    else:
        query = query.order_by(desc(HistoriaReddit.nota_media))
        
    result = await db.execute(query)
    historias = result.scalars().all()
    
    for h in historias:
        if h.texto_narrado:
            words = len(h.texto_narrado.split())
            h.num_palavras_calc = words
            minutes = (words / 150.0) / 1.3
            total_seconds = int(minutes * 60)
            mins = total_seconds // 60
            secs = total_seconds % 60
            h.tempo_estimado_calc = f"{mins}m{secs:02d}s"
        else:
            h.num_palavras_calc = 0
            h.tempo_estimado_calc = "--"
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    processing_ia_ids = r.smembers("processing_ia_ids") or set()
    
    return templates.TemplateResponse(request=request, name="curadoria.html", context={"historias": historias, "badges": badges, "sort": sort, "processing_ids": list(processing_ia_ids)})

@router_ui.get("/rejeitados", response_class=HTMLResponse)
async def rejeitados_page(request: Request, sort: Optional[str] = "data_recente", origem: Optional[str] = "todas", db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    # Calculate summary counts
    count_ia_nota_res = await db.execute(select(func.count(HistoriaReddit.id)).where(HistoriaReddit.status == StatusHistoria.REPROVADO_NOTA))
    count_ia_curto_res = await db.execute(select(func.count(HistoriaReddit.id)).where(HistoriaReddit.status == StatusHistoria.REPROVADO_CURTO))
    count_po_res = await db.execute(select(func.count(HistoriaReddit.id)).where(HistoriaReddit.status == StatusHistoria.REPROVADO_PO))
    count_perm_res = await db.execute(select(func.count(HistoriaReddit.id)).where(HistoriaReddit.status == StatusHistoria.EXCLUIDO_PERMANENTE))
    
    summary = {
        "ia_nota": count_ia_nota_res.scalar(),
        "ia_curto": count_ia_curto_res.scalar(),
        "humano": count_po_res.scalar(),
        "permanente": count_perm_res.scalar()
    }

    query = select(HistoriaReddit)
    
    if origem == "ia_nota":
        query = query.where(HistoriaReddit.status == StatusHistoria.REPROVADO_NOTA)
    elif origem == "ia_curto":
        query = query.where(HistoriaReddit.status == StatusHistoria.REPROVADO_CURTO)
    elif origem == "humano":
        query = query.where(HistoriaReddit.status == StatusHistoria.REPROVADO_PO)
    else:
        query = query.where(HistoriaReddit.status.in_([StatusHistoria.REPROVADO_NOTA, StatusHistoria.REPROVADO_CURTO, StatusHistoria.REPROVADO_PO]))
    
    if sort == "data_antiga":
        query = query.order_by(HistoriaReddit.data_criacao.asc())
    elif sort == "nota_desc":
        query = query.order_by(desc(HistoriaReddit.nota_media))
    elif sort == "nota_asc":
        query = query.order_by(HistoriaReddit.nota_media.asc())
    else: # data_recente
        query = query.order_by(desc(HistoriaReddit.data_criacao))
        
    result = await db.execute(query)
    historias = result.scalars().all()
    
    return templates.TemplateResponse(request=request, name="rejeitados.html", context={
        "historias": historias, 
        "badges": badges, 
        "sort": sort, 
        "origem": origem,
        "summary": summary
    })

@router_ui.post("/rejeitados/esvaziar")
async def esvaziar_lixeira(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(HistoriaReddit)
        .where(HistoriaReddit.status.in_([StatusHistoria.REPROVADO_NOTA, StatusHistoria.REPROVADO_CURTO, StatusHistoria.REPROVADO_PO]))
    )
    historias = result.scalars().all()
    for historia in historias:
        historia.status = StatusHistoria.EXCLUIDO_PERMANENTE
    await db.commit()
    return RedirectResponse(url="/rejeitados", status_code=303)

@router_ui.post("/rejeitados/lote-restaurar")
async def lote_restaurar_rejeitados(ids: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not ids:
        return RedirectResponse(url="/rejeitados", status_code=303)
    try:
        import json
        lista_ids = json.loads(ids)
    except:
        return RedirectResponse(url="/rejeitados", status_code=303)
        
    if lista_ids:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(lista_ids)))
        historias = result.scalars().all()
        for historia in historias:
            historia.status = StatusHistoria.REVISAO_HUMANA
        await db.commit()
    return RedirectResponse(url="/rejeitados", status_code=303)

@router_ui.post("/rejeitados/lote-excluir")
async def lote_excluir_rejeitados(ids: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not ids:
        return RedirectResponse(url="/rejeitados", status_code=303)
    try:
        import json
        lista_ids = json.loads(ids)
    except:
        return RedirectResponse(url="/rejeitados", status_code=303)
        
    if lista_ids:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(lista_ids)))
        historias = result.scalars().all()
        for historia in historias:
            historia.status = StatusHistoria.EXCLUIDO_PERMANENTE
        await db.commit()
    return RedirectResponse(url="/rejeitados", status_code=303)

@router_ui.post("/rejeitados/{id_historia}/restaurar")
async def restaurar_historia_rejeitada(id_historia: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id_historia))
    historia = result.scalar_one_or_none()
    if historia:
        historia.status = StatusHistoria.REVISAO_HUMANA
        await db.commit()
    return RedirectResponse(url="/rejeitados", status_code=303)

@router_ui.post("/curadoria/lote-aprovar")
async def lote_aprovar_curadoria(ids: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not ids:
        return RedirectResponse(url="/curadoria", status_code=303)
        
    lista_ids = [uuid.UUID(i.strip()) for i in ids.split(',') if i.strip()]
    if lista_ids:
        from app.workers.tasks_media import gerar_audio_task
        from datetime import datetime
        
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(lista_ids)))
        historias = result.scalars().all()
        
        for historia in historias:
            if historia.status == StatusHistoria.REVISAO_HUMANA or historia.status == StatusHistoria.ERRO_FATAL_AUDIO:
                historia.status = StatusHistoria.LIBERADO_AUDIO
                historia.data_liberacao_audio = datetime.utcnow()
                gerar_audio_task.apply_async(args=[str(historia.id)], queue='media_tasks')
                
        await db.commit()
        
    return RedirectResponse(url="/curadoria", status_code=303)

@router_ui.get("/montagem-audio", response_class=HTMLResponse)
async def montagem_audio_page(request: Request, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    result = await db.execute(
        select(HistoriaReddit)
        .where(HistoriaReddit.status.in_([
            StatusHistoria.LIBERADO_AUDIO,
            StatusHistoria.AUDIO_PRONTO,
            StatusHistoria.ERRO_FATAL_AUDIO,
            StatusHistoria.ERRO_FATAL_RENDERIZACAO
        ]))
    )
    historias = result.scalars().all()
    
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    processing_audio_id = r.get("processing_audio_id")
    
    # Ordenação customizada:
    # 1. Em Processamento
    # 2. Pendentes (LIBERADO_AUDIO)
    # 3. Prontos (AUDIO_PRONTO)
    # 4. Erros e outros
    def sort_key(h):
        if processing_audio_id and str(h.id) == processing_audio_id:
            return 0
        if h.status == StatusHistoria.LIBERADO_AUDIO:
            return 1
        if h.status == StatusHistoria.AUDIO_PRONTO:
            return 2
        return 3

    historias = sorted(historias, key=lambda h: (sort_key(h), h.data_criacao), reverse=False)
    # reverse=False para a chave sort_key asc (0, 1, 2, 3), 
    # Para data_criacao, os mais antigos no topo (ou seja, ordem natural FIFO)
    # Se quiser LIFO nas subcategorias, podemos usar -h.data_criacao.timestamp(), mas FIFO faz mais sentido para filas.
    
    config = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
    config = config.scalars().first()
    engine_name = "Edge TTS (Microsoft)" if config and config.usar_edge_tts else "ElevenLabs"
    
    return templates.TemplateResponse(request=request, name="montagem_audio.html", context={
        "historias": historias, 
        "badges": badges,
        "processing_audio_id": processing_audio_id,
        "engine_name": engine_name
    })

import json

@router_ui.post("/montagem-audio/lote-renderizar")
async def lote_renderizar_audio(lote_data: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not lote_data:
        return RedirectResponse(url="/montagem-audio", status_code=303)
        
    try:
        dados = json.loads(lote_data)
    except:
        return RedirectResponse(url="/montagem-audio", status_code=303)
        
    if dados:
        from app.workers.tasks_media import renderizar_video_task
        for item in dados:
            try:
                hist_id = uuid.UUID(item['id'])
                result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == hist_id))
                historia = result.scalars().first()
                if historia and historia.status in [StatusHistoria.AUDIO_PRONTO, StatusHistoria.ERRO_FATAL_RENDERIZACAO]:
                    historia.status = StatusHistoria.LIBERADO_RENDERIZACAO
                    velocidade = item.get('velocidade', '1.3')
                    historia.velocidade_video = float(velocidade)
                    renderizar_video_task.apply_async(args=[str(historia.id), velocidade], queue='media_tasks')
            except Exception as e:
                import logging
                logging.error(f"Erro em lote_renderizar_audio para item {item}: {e}")
                
        await db.commit()
        
    return RedirectResponse(url="/montagem-audio", status_code=303)

@router_ui.post("/montagem-audio/lote-voltar-curadoria")
async def lote_voltar_curadoria_audio(lote_data: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not lote_data:
        return RedirectResponse(url="/montagem-audio", status_code=303)
        
    try:
        dados = json.loads(lote_data)
    except:
        return RedirectResponse(url="/montagem-audio", status_code=303)
        
    if dados:
        for item in dados:
            try:
                hist_id = uuid.UUID(item['id'])
                result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == hist_id))
                historia = result.scalars().first()
                if historia:
                    try:
                        import os
                        filepath = f"/app/output/{historia.id}_temp_audio.mp3"
                        if os.path.exists(filepath):
                            os.remove(filepath)
                    except:
                        pass
                    historia.duracao_audio_segundos = None
                    historia.status = StatusHistoria.REVISAO_HUMANA
                    from datetime import datetime
                    historia.data_analise_ia = datetime.utcnow()
            except:
                pass
        await db.commit()
        
    return RedirectResponse(url="/montagem-audio", status_code=303)

@router_ui.post("/montagem-audio/lote-descartar")
async def lote_descartar_audio(lote_data: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not lote_data:
        return RedirectResponse(url="/montagem-audio", status_code=303)
        
    try:
        dados = json.loads(lote_data)
    except:
        return RedirectResponse(url="/montagem-audio", status_code=303)
        
    if dados:
        for item in dados:
            try:
                hist_id = uuid.UUID(item['id'])
                result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == hist_id))
                historia = result.scalars().first()
                if historia:
                    try:
                        import os
                        filepath = f"/app/output/{historia.id}_temp_audio.mp3"
                        if os.path.exists(filepath):
                            os.remove(filepath)
                    except:
                        pass
                    historia.duracao_audio_segundos = None
                    historia.status = StatusHistoria.REPROVADO_PO
            except:
                pass
        await db.commit()
        
    return RedirectResponse(url="/montagem-audio", status_code=303)

@router_ui.post("/montagem-audio/{id}/voltar-curadoria")
async def voltar_curadoria_audio(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        try:
            import os
            filepath = f"/app/output/{historia.id}_temp_audio.mp3"
            if os.path.exists(filepath):
                os.remove(filepath)
        except:
            pass
        historia.duracao_audio_segundos = None
        historia.status = StatusHistoria.REVISAO_HUMANA
        from datetime import datetime
        historia.data_analise_ia = datetime.utcnow()
        await db.commit()
    return RedirectResponse(url="/montagem-audio", status_code=303)

@router_ui.post("/montagem-audio/{id}/descartar")
async def descartar_audio_lixeira(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        try:
            import os
            filepath = f"/app/output/{historia.id}_temp_audio.mp3"
            if os.path.exists(filepath):
                os.remove(filepath)
        except:
            pass
        historia.duracao_audio_segundos = None
        historia.status = StatusHistoria.REPROVADO_PO
        await db.commit()
    return RedirectResponse(url="/montagem-audio", status_code=303)


@router_ui.post("/api/historia/{id}/refazer-capa")
async def refazer_capa(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    from app.services.ai_services import gerar_gancho_imagem_e_titulo
    from fastapi.responses import JSONResponse
    
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    
    if not historia:
        return JSONResponse(status_code=404, content={"message": "História não encontrada."})
        
    try:
        texto_base = historia.texto_narrado if historia.texto_narrado else historia.texto_original
        gancho = await gerar_gancho_imagem_e_titulo(texto_base, historia.id_post_reddit, None)
        
        if gancho:
            if gancho.get('titulo_gancho'):
                historia.titulo_gancho = gancho.get('titulo_gancho')
            if gancho.get('caminho_imagem_gancho'):
                historia.caminho_imagem_gancho = gancho.get('caminho_imagem_gancho')
            historia.custo_ia_texto = (historia.custo_ia_texto or 0) + gancho.get('custo_ia_texto', 0.0)
            
            await db.commit()
            return JSONResponse(status_code=200, content={"message": "Capa gerada com sucesso!"})
        else:
            return JSONResponse(status_code=500, content={"message": "Falha na geração do gancho (retorno vazio)."})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return JSONResponse(status_code=500, content={"message": f"Erro interno: {str(e)}"})


@router_ui.get("/montagem-video", response_class=HTMLResponse)
async def montagem_video_page(request: Request, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    result = await db.execute(
        select(HistoriaReddit)
        .where(HistoriaReddit.status.in_([
            StatusHistoria.LIBERADO_PRODUCAO, 
            StatusHistoria.LIBERADO_RENDERIZACAO, 
            StatusHistoria.ERRO_FATAL_RENDERIZACAO
        ]))
    )
    historias = result.scalars().all()
    
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    processing_video_id = r.get("processing_video_id")
    
    def sort_key(h):
        if processing_video_id and str(h.id) == processing_video_id:
            return 0
        if h.status in [StatusHistoria.LIBERADO_PRODUCAO, StatusHistoria.LIBERADO_RENDERIZACAO]:
            return 1
        return 2

    historias = sorted(historias, key=lambda h: (sort_key(h), h.data_criacao), reverse=False)
    
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    processing_video_id = r.get("processing_video_id")
    
    return templates.TemplateResponse(request=request, name="montagem_video.html", context={
        "historias": historias, 
        "badges": badges,
        "processing_video_id": processing_video_id
    })



@router_ui.get("/internacionalizacao", response_class=HTMLResponse)
async def internacionalizacao_page(request: Request, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    result = await db.execute(
        select(HistoriaReddit)
        .where(HistoriaReddit.status == StatusHistoria.INTERNACIONALIZACAO)
        .where(HistoriaReddit.parent_id == None)
        .order_by(desc(HistoriaReddit.data_criacao))
    )
    historias_pai = result.scalars().all()
    
    historias_filhas = {h.id: [] for h in historias_pai}
    pai_ids = [h.id for h in historias_pai]
    if pai_ids:
        res_filhas = await db.execute(
            select(HistoriaReddit).where(HistoriaReddit.parent_id.in_(pai_ids)).order_by(desc(HistoriaReddit.data_criacao))
        )
        for f in res_filhas.scalars().all():
            historias_filhas[f.parent_id].append(f)
            
    return templates.TemplateResponse(request=request, name="internacionalizacao.html", context={
        "historias_pai": historias_pai,
        "historias_filhas": historias_filhas,
        "badges": badges
    })

from fastapi import Query

@router_ui.get("/distribuicao", response_class=HTMLResponse)
async def distribuicao_page(
    request: Request,
    db: AsyncSession = Depends(get_db),
    badges: dict = Depends(get_menu_badges),
    search: Optional[str] = None,
    status_pub: Optional[str] = "nao_publicados",
    sort_order: Optional[str] = "dist_desc",
    hide_lang: list[str] = Query(default=["en", "es"])
):
    query = select(HistoriaReddit).where(HistoriaReddit.status.in_([StatusHistoria.DISTRIBUICAO, StatusHistoria.PUBLICADO]))

    # Search filter
    if search:
        query = query.where(HistoriaReddit.titulo_gancho.ilike(f"%{search}%") | HistoriaReddit.titulo_reddit.ilike(f"%{search}%"))

    # Status filter
    if status_pub == "publicados":
        query = query.where(HistoriaReddit.status == StatusHistoria.PUBLICADO)
    elif status_pub == "nao_publicados":
        query = query.where(HistoriaReddit.status == StatusHistoria.DISTRIBUICAO)

    # Language hide filter
    if hide_lang:
        query = query.where(HistoriaReddit.idioma.not_in(hide_lang))

    # Sorting
    if sort_order == "pub_desc":
        query = query.order_by(desc(HistoriaReddit.data_publicacao))
    elif sort_order == "pub_asc":
        query = query.order_by(HistoriaReddit.data_publicacao)
    elif sort_order == "dist_desc":
        query = query.order_by(desc(HistoriaReddit.data_distribuicao))
    elif sort_order == "dist_asc":
        query = query.order_by(HistoriaReddit.data_distribuicao)
    elif sort_order == "criacao_desc":
        query = query.order_by(desc(HistoriaReddit.data_criacao))
    elif sort_order == "criacao_asc":
        query = query.order_by(HistoriaReddit.data_criacao)
    else:
        query = query.order_by(desc(HistoriaReddit.data_criacao)) # fallback

    result = await db.execute(query)
    historias = result.scalars().all()
    
    historias_single = []
    series_parent_ids = set()
    
    for h in historias:
        if h.parent_id and h.parte_numero is not None:
            series_parent_ids.add(h.parent_id)
        else:
            historias_single.append(h)
            
    sagas = []
    if series_parent_ids:
        res_maes = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(list(series_parent_ids))))
        maes_list = res_maes.scalars().all()
        maes_dict = {m.id: m for m in maes_list}
        
        sagas_dict = {}
        for h in historias:
            if h.parent_id and h.parte_numero is not None:
                if h.parent_id not in sagas_dict:
                    sagas_dict[h.parent_id] = {
                        "mae": maes_dict.get(h.parent_id),
                        "partes": []
                    }
                sagas_dict[h.parent_id]["partes"].append(h)
        sagas = list(sagas_dict.values())
    
    import json
    def safe_json_loads(s):
        if not s: return None
        try:
            return json.loads(s)
        except:
            return None
            
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    processing_saga_ids = r.smembers("processing_saga_ids") or set()
            
    return templates.TemplateResponse(request=request, name="distribuicao.html", context={
        "historias": historias_single,
        "sagas": sagas,
        "processing_saga_ids": list(processing_saga_ids),
        "badges": badges,
        "search": search or "",
        "status_pub": status_pub,
        "sort_order": sort_order,
        "hide_lang": hide_lang,
        "safe_json_loads": safe_json_loads
    })

@router_ui.post("/api/youtube/sync")
async def sync_youtube_metrics(request: Request):
    from app.workers.tasks_beat import atualizar_engajamento_youtube_task
    # Chama a task Celery de forma assíncrona garantindo que vai para a fila certa
    atualizar_engajamento_youtube_task.apply_async(queue="io_tasks")
    
    referer = request.headers.get("referer", "/distribuicao")
    return RedirectResponse(url=referer, status_code=status.HTTP_303_SEE_OTHER)

@router_ui.get("/acervo", response_class=HTMLResponse)
async def acervo_page(request: Request, sort: str = "recentes", db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    query = (
        select(HistoriaReddit)
        .where(HistoriaReddit.status == StatusHistoria.BETA_PRONTO)
    )
    
    if sort == "antigos":
        query = query.order_by(HistoriaReddit.data_criacao.asc())
    elif sort == "nota_maior":
        query = query.order_by(HistoriaReddit.nota_media.desc())
    elif sort == "ups_maior":
        query = query.order_by(HistoriaReddit.ups.desc())
    else:
        query = query.order_by(HistoriaReddit.data_criacao.desc())
        
    result = await db.execute(query)
    all_ready = result.scalars().all()
    
    historias_single = []
    series_parent_ids = set()
    
    for h in all_ready:
        if h.parent_id and h.parte_numero is not None:
            series_parent_ids.add(h.parent_id)
        else:
            historias_single.append(h)
            
    sagas_prontas = []
    if series_parent_ids:
        res_maes = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(list(series_parent_ids))))
        sagas_prontas = res_maes.scalars().all()
            
    return templates.TemplateResponse(request=request, name="acervo.html", context={
        "historias_single": historias_single,
        "sagas": sagas_prontas,
        "badges": badges,
        "current_sort": sort
    })

@router_ui.post("/acervo/lote-distribuir")
async def lote_distribuir_acervo(ids: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not ids: return RedirectResponse(url="/acervo", status_code=303)
    try:
        import json
        lista_ids = json.loads(ids)
    except:
        return RedirectResponse(url="/acervo", status_code=303)
    if lista_ids:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(lista_ids)))
        historias = result.scalars().all()
        for historia in historias:
            historia.status = StatusHistoria.DISTRIBUICAO
        await db.commit()
    return RedirectResponse(url="/acervo", status_code=303)

@router_ui.post("/acervo/lote-internacionalizar")
async def lote_internacionalizar_acervo(ids: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not ids: return RedirectResponse(url="/acervo", status_code=303)
    try:
        import json
        lista_ids = json.loads(ids)
    except:
        return RedirectResponse(url="/acervo", status_code=303)
    if lista_ids:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(lista_ids)))
        historias = result.scalars().all()
        for historia in historias:
            if not historia.parent_id:
                historia.status = StatusHistoria.INTERNACIONALIZACAO
        await db.commit()
    return RedirectResponse(url="/acervo", status_code=303)

@router_ui.post("/acervo/lote-excluir")
async def lote_excluir_acervo(ids: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not ids: return RedirectResponse(url="/acervo", status_code=303)
    try:
        import json
        lista_ids = json.loads(ids)
    except:
        return RedirectResponse(url="/acervo", status_code=303)
    if lista_ids:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(lista_ids)))
        historias = result.scalars().all()
        for historia in historias:
            historia.status = StatusHistoria.EXCLUIDO_PERMANENTE
        await db.commit()
    return RedirectResponse(url="/acervo", status_code=303)

@router_ui.post("/acervo/lote-curadoria")
async def lote_curadoria_acervo(ids: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not ids: return RedirectResponse(url="/acervo", status_code=303)
    try:
        import json
        lista_ids = json.loads(ids)
    except:
        return RedirectResponse(url="/acervo", status_code=303)
    if lista_ids:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(lista_ids)))
        historias = result.scalars().all()
        for historia in historias:
            historia.status = StatusHistoria.REVISAO_HUMANA
        await db.commit()
    return RedirectResponse(url="/acervo", status_code=303)

@router_ui.post("/acervo/lote-audio")
async def lote_audio_acervo(ids: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not ids: return RedirectResponse(url="/acervo", status_code=303)
    try:
        import json
        lista_ids = json.loads(ids)
    except:
        return RedirectResponse(url="/acervo", status_code=303)
    if lista_ids:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(lista_ids)))
        historias = result.scalars().all()
        for historia in historias:
            historia.status = StatusHistoria.LIBERADO_AUDIO
        await db.commit()
    return RedirectResponse(url="/acervo", status_code=303)

@router_ui.post("/acervo/lote-refazer")
async def lote_refazer_acervo(ids: str = Form(...), db: AsyncSession = Depends(get_db)):
    if not ids: return RedirectResponse(url="/acervo", status_code=303)
    try:
        import json
        lista_ids = json.loads(ids)
    except:
        return RedirectResponse(url="/acervo", status_code=303)
    if lista_ids:
        result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id.in_(lista_ids)))
        historias = result.scalars().all()
        from app.workers.tasks_media import renderizar_video_task
        for historia in historias:
            historia.status = StatusHistoria.LIBERADO_RENDERIZACAO
            velocidade = historia.velocidade_video or 1.0
            renderizar_video_task.apply_async(args=[str(historia.id), str(velocidade)], queue='media_tasks')
        await db.commit()
    return RedirectResponse(url="/montagem-video", status_code=303)

async def log_generator(request: Request):
    log_file_path = "/app/logs/worker_media.log"
    # Aguarda o arquivo existir se container demorar
    while not os.path.exists(log_file_path):
        if await request.is_disconnected():
            return
        await asyncio.sleep(1)
        
    with open(log_file_path, "r", encoding="utf-8") as f:
        # Vai para o final do arquivo na primeira carga se for muito grande
        # Mas vamos ler tudo para ter contexto caso seja pequeno?
        # A instrução diz tail -f, ler apenas novas. Mas se quisermos ler o fim:
        f.seek(0, 2)
        while True:
            if await request.is_disconnected():
                break
            line = f.readline()
            if not line:
                await asyncio.sleep(0.5)
                continue
            # Substitui quebras para garantir formato SSE
            clean_line = line.strip().replace("\n", " ")
            if clean_line:
                yield f"data: {clean_line}\n\n"

@router_ui.get("/api/logs/stream")
async def stream_logs(request: Request):
    return StreamingResponse(log_generator(request), media_type="text/event-stream")

@router_ui.get("/historia/{id}", response_class=HTMLResponse)
async def detalhe_historia(request: Request, id: uuid.UUID, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    """
    Visão Detalhada para QA do Roteiro.
    """
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail="História não encontrada")
    
    if historia.comentarios_reddit is None:
        from app.services.reddit_service import obter_comentarios_post
        from app.db.models import ConfiguracaoSistema
        import asyncio
        
        result_config = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
        config = result_config.scalars().first()
        
        loop = asyncio.get_event_loop()
        comentarios = await loop.run_in_executor(
            None, 
            obter_comentarios_post, 
            historia.id_post_reddit, 20, historia.subreddit, config.reddit_cookie if config else None, config.reddit_user_agent if config else None
        )
        historia.comentarios_reddit = comentarios or ""
        await db.commit()
    
    import json
    comentarios_limpos = historia.comentarios_reddit
    raw_list = []
    
    if isinstance(comentarios_limpos, str):
        try:
            parsed = json.loads(comentarios_limpos)
            if isinstance(parsed, list):
                raw_list = parsed
            else:
                parsed_str = str(parsed)
                if "---" in parsed_str:
                    raw_list = [c.strip() for c in parsed_str.split("---") if c.strip()]
                else:
                    raw_list = [parsed_str.strip()] if parsed_str.strip() else []
        except Exception:
            if "---" in comentarios_limpos:
                raw_list = [c.strip() for c in comentarios_limpos.split("---") if c.strip()]
            else:
                raw_list = [comentarios_limpos.strip()] if comentarios_limpos.strip() else []
    elif isinstance(comentarios_limpos, list):
        raw_list = comentarios_limpos
        
    lista_comentarios = []
    for item in raw_list:
        item_str = str(item)
        # O scraper agora converteu os '\n' originais do usuário em '<br>'
        # Então os únicos '\n' que existem na string são os que separam os níveis de comentário (Nível 1, 2, 3)
        parts = item_str.split("\n")
        main_text = parts[0]
        replies = parts[1:] if len(parts) > 1 else []
        lista_comentarios.append({"main": main_text, "replies": replies})
    if historia.texto_narrado:
        words = len(historia.texto_narrado.split())
        historia._num_palavras = words
        minutes = (words / 150.0) / 1.3
        total_seconds = int(minutes * 60)
        mins = total_seconds // 60
        secs = total_seconds % 60
        historia._tempo_estimado = f"{mins}m{secs:02d}s"
    else:
        historia._num_palavras = 0
        historia._tempo_estimado = "--"

    return templates.TemplateResponse(request=request, name="detalhe_historia.html", context={
        "historia": historia, 
        "badges": badges,
        "comentarios_limpos": comentarios_limpos,
        "lista_comentarios": lista_comentarios
    })

@router_ui.post("/historia/{id}/inbox")
async def devolver_inbox(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        historia.status = StatusHistoria.AGUARDANDO_APROVACAO
        # Remove os resultados de IA para começar do zero
        historia.texto_narrado = None
        historia.nota_gemini = None
        historia.titulo_gancho = None
        await db.commit()
    return RedirectResponse(url="/inbox", status_code=303)

@router_ui.post("/historia/{id}/aprovar")
async def aprovar_historia(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    from datetime import datetime
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail="Historia nao encontrada")
        
    historia.status = StatusHistoria.LIBERADO_AUDIO
    historia.data_liberacao_audio = datetime.utcnow()
    historia.log_erro = None
    await db.commit()
    
    from app.workers.celery_app import celery_app
    celery_app.send_task("app.workers.tasks_media.gerar_audio_task", args=[str(historia.id)], queue='media_tasks')
    
    return RedirectResponse(url="/montagem-audio", status_code=status.HTTP_303_SEE_OTHER)

@router_ui.post("/historia/{id}/renderizar")
async def aprovar_para_renderizacao(
    id: uuid.UUID, 
    velocidade: str = Form("1.0"),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    allowed_statuses = [
        StatusHistoria.AUDIO_PRONTO, 
        StatusHistoria.ERRO_FATAL_RENDERIZACAO,
        StatusHistoria.BETA_PRONTO,
        StatusHistoria.PUBLICADO,
        StatusHistoria.DISTRIBUICAO
    ]
    if historia and historia.status in allowed_statuses:
        historia.status = StatusHistoria.LIBERADO_RENDERIZACAO
        try:
            historia.velocidade_video = float(velocidade)
        except:
            historia.velocidade_video = 1.0
        await db.commit()
        from app.workers.tasks_media import renderizar_video_task
        renderizar_video_task.apply_async(args=[str(id), velocidade], queue='media_tasks')
    return RedirectResponse(url="/montagem-video", status_code=status.HTTP_303_SEE_OTHER)

@router_ui.post("/historia/{id}/rejeitar")
async def rejeitar_historia(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail="Historia nao encontrada")
        
    historia.status = StatusHistoria.REPROVADO_PO
    await db.commit()
    return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)

@router_ui.post('/historia/{id}/deletar')
async def deletar_historia(request: Request, id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail='Historia nao encontrada')
        
    # Remove arquivos fisicos (capa, audio, video) para economizar espaço
    import os
    capa_raw = None
    if historia.caminho_imagem_gancho:
        try:
            caminho_base = historia.caminho_imagem_gancho.rsplit('.', 1)[0]
            ext = historia.caminho_imagem_gancho.rsplit('.', 1)[1]
            capa_raw = f"{caminho_base}_raw.{ext}"
        except:
            pass
            
    arquivos_para_apagar = [
        historia.caminho_imagem_gancho,
        capa_raw,
        f"/app/output/{id}_temp_audio.mp3",
        f"/app/output/{id}_temp_subs.json",
        f"/app/output/{id}_temp.ass",
        f"/app/output/BETA_{id}_final.mp4"
    ]
    for filepath in arquivos_para_apagar:
        if filepath and os.path.exists(filepath):
            try: os.remove(filepath)
            except: pass
            
    await db.delete(historia)
    await db.commit()
    
    referer = request.headers.get("referer")
    if referer and "/acervo" in referer:
        return RedirectResponse(url='/acervo', status_code=status.HTTP_303_SEE_OTHER)
    return RedirectResponse(url='/', status_code=status.HTTP_303_SEE_OTHER)

async def processar_analise_manual_background(id: uuid.UUID):
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    try:
        async for session in get_db():
            result = await session.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
            historia = result.scalars().first()
            if not historia:
                return

            from app.services.ai_services import avaliar_historia_router, gerar_gancho_imagem_e_titulo
            res = await avaliar_historia_router(historia.texto_original)
            historia.texto_narrado = res.get('texto_reescrito')
            historia.genero_narrador = res.get('genero_narrador')
            historia.justificativa_ia = res.get('justificativa')
            
            nota = res.get('nota')
            if nota is not None:
                try:
                    historia.nota_gemini = float(nota)
                    historia.nota_media = historia.nota_gemini
                except ValueError:
                    historia.nota_gemini = None
                    historia.nota_media = None
            else:
                historia.nota_gemini = None
                historia.nota_media = None
                
            nota_viral = res.get('nota_viral')
            if nota_viral is not None:
                try:
                    historia.nota_viral = float(nota_viral)
                except ValueError:
                    historia.nota_viral = None
            else:
                historia.nota_viral = None
            
            # Como a análise aqui é manual/solicitada pelo usuário, a história SEMPRE volta para a Curadoria (Revisão Humana)
            historia.status = StatusHistoria.REVISAO_HUMANA
            historia.data_analise_ia = (datetime.utcnow() - timedelta(hours=3))
            
            if historia.nota_gemini and historia.nota_gemini >= 7:
                # Gera gancho e imagem apenas se a nota for boa para economizar tokens
                texto_base = historia.texto_narrado if historia.texto_narrado else historia.texto_original
                gancho = await gerar_gancho_imagem_e_titulo(texto_base, historia.id_post_reddit)
                historia.titulo_gancho = gancho.get('titulo_gancho')
                historia.caminho_imagem_gancho = gancho.get('caminho_imagem_gancho')
                historia.custo_ia_texto = (historia.custo_ia_texto or 0) + gancho.get('custo_ia_texto', 0.0)
            
            await session.commit()
            break # Exit after successful commit
    except Exception as e:
        import logging
        logging.error(f"Erro analisando manual: {e}")
    finally:
        r.srem("processing_ia_ids", str(id))

@router_ui.post('/historia/{id}/analisar')
async def analisar_historia_ia(id: uuid.UUID, background_tasks: BackgroundTasks, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail='Historia no encontrada')
    
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    r.sadd("processing_ia_ids", str(id))
    
    background_tasks.add_task(processar_analise_manual_background, id)
    
    return RedirectResponse(url='/curadoria', status_code=status.HTTP_303_SEE_OTHER)

@router_ui.post("/historia/{id}/traduzir")
async def traduzir_historia(id: uuid.UUID, idioma: str = Form(...), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia_pai = result.scalars().first()
    if not historia_pai:
        raise HTTPException(status_code=404, detail="Historia nao encontrada")
        
    nova_historia = HistoriaReddit(
        id_post_reddit=historia_pai.id_post_reddit,
        subreddit=historia_pai.subreddit,
        titulo_reddit=historia_pai.titulo_reddit,
        texto_original=historia_pai.texto_original,
        comentarios_reddit=historia_pai.comentarios_reddit,
        texto_narrado=None,
        genero_narrador=historia_pai.genero_narrador,
        justificativa_ia="Tradução Automática IA Async",
        ups=historia_pai.ups,
        num_comments=historia_pai.num_comments,
        upvote_ratio=historia_pai.upvote_ratio,
        nota_media=historia_pai.nota_media,
        status=StatusHistoria.TRADUZINDO,
        titulo_gancho=None,
        parent_id=historia_pai.id,
        idioma=idioma
    )
    db.add(nova_historia)
    await db.flush()
    await db.commit()
    
    from app.workers.celery_app import celery_app
    celery_app.send_task("app.workers.tasks_media.traduzir_historia_task", args=[str(nova_historia.id), idioma], queue='media_tasks')
    
    return RedirectResponse(url="/internacionalizacao", status_code=status.HTTP_303_SEE_OTHER)

@router_ui.post("/historia/{id}/mover/{novo_status}")
async def mover_historia(id: uuid.UUID, novo_status: str, request: Request, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail="Historia nao encontrada")
        
    if novo_status == "DISTRIBUICAO":
        # Bloqueia se alguma filha estiver em processamento
        res_filhas = await db.execute(
            select(HistoriaReddit)
            .where(HistoriaReddit.parent_id == id)
            .where(HistoriaReddit.status.not_in([StatusHistoria.BETA_PRONTO, StatusHistoria.PUBLICADO, StatusHistoria.ERRO_FATAL_AUDIO, StatusHistoria.ERRO_FATAL_RENDERIZACAO]))
        )
        em_processamento = res_filhas.scalars().all()
        if em_processamento:
            # Em vez de erro feio, redireciona de volta. (O ideal seria flash message)
            referer = request.headers.get("referer", "/internacionalizacao")
            return RedirectResponse(url=referer, status_code=status.HTTP_303_SEE_OTHER)

    try:
        from datetime import datetime
        historia.status = StatusHistoria[novo_status]
        if novo_status == "DISTRIBUICAO":
            historia.data_distribuicao = (datetime.utcnow() - timedelta(hours=3))
            
            from app.workers.celery_app import celery_app
            if not historia.descricao_youtube:
                celery_app.send_task("app.workers.tasks_io.gerar_descricao_youtube_task", args=[str(historia.id)], queue='io_tasks')
                
            # Mover filhos para distribuicao e gerar descricao
            res_filhas_todas = await db.execute(select(HistoriaReddit).where(HistoriaReddit.parent_id == id))
            for f in res_filhas_todas.scalars().all():
                if f.status != StatusHistoria.PUBLICADO:
                    f.status = StatusHistoria.DISTRIBUICAO
                    f.data_distribuicao = (datetime.utcnow() - timedelta(hours=3))
                if not f.descricao_youtube:
                    celery_app.send_task("app.workers.tasks_io.gerar_descricao_youtube_task", args=[str(f.id)], queue='io_tasks')
                    
        await db.commit()
    except KeyError:
        raise HTTPException(status_code=400, detail="Status inválido")

    if novo_status == "INTERNACIONALIZACAO":
        return RedirectResponse(url="/internacionalizacao", status_code=status.HTTP_303_SEE_OTHER)
    elif novo_status == "DISTRIBUICAO":
        return RedirectResponse(url="/distribuicao", status_code=status.HTTP_303_SEE_OTHER)
    return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)

@router_ui.post("/historia/{id}/gerar-descricao")
async def gerar_descricao(id: uuid.UUID, request: Request, db: AsyncSession = Depends(get_db)):
    from app.services.ai_services import gerar_descricao_youtube
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        resultado_desc = await gerar_descricao_youtube(historia.texto_narrado or historia.texto_original, historia.titulo_gancho or historia.titulo_reddit, historia.idioma)
        historia.descricao_youtube = resultado_desc.get("descricao", "")
        historia.custo_ia_texto = (historia.custo_ia_texto or 0.0) + resultado_desc.get("custo_usd", 0.0)
        await db.commit()
    referer = request.headers.get("referer", "/distribuicao")
    return RedirectResponse(url=referer, status_code=status.HTTP_303_SEE_OTHER)

@router_ui.get("/historia/{id}/baixar")
async def baixar_video_acelerado(id: uuid.UUID, velocidade: float = 1.0, db: AsyncSession = Depends(get_db)):
    import os
    import re
    import asyncio
    from fastapi.responses import FileResponse
    
    # Buscar a história para pegar o título
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    
    base_name = f"Video_{id}"
    if historia:
        titulo_bruto = historia.titulo_gancho or historia.titulo_reddit
        if titulo_bruto:
            # Sanitizar para evitar erro no nome do arquivo no Windows/Mac
            clean_title = re.sub(r'[\\/*?:"<>|]', "", titulo_bruto)
            clean_title = " ".join(clean_title.split())[:100].strip()
            if clean_title:
                base_name = clean_title

    input_path = f"/app/output/BETA_{id}_final.mp4"
    if not os.path.exists(input_path):
        raise HTTPException(status_code=404, detail="Vídeo não encontrado no servidor")
    
    velocidade_original = getattr(historia, 'velocidade_video', 1.0)
    if velocidade_original is None:
        velocidade_original = 1.0
        
    if abs(velocidade - velocidade_original) < 0.01:
        return FileResponse(input_path, filename=f"{base_name}.mp4", media_type="video/mp4")
        
    output_path = f"/app/output/BETA_{id}_final_{velocidade}x.mp4"
    if os.path.exists(output_path):
        return FileResponse(output_path, filename=f"{base_name} ({velocidade}x).mp4", media_type="video/mp4")
        
    fator = round(velocidade / velocidade_original, 4)
    v_pts = round(1.0 / fator, 4)
    temp_output_path = f"{output_path}.tmp.mp4"
    
    comando = [
        "ffmpeg", "-y", "-i", input_path,
        "-filter_complex", f"[0:v]setpts={v_pts}*PTS[v];[0:a]atempo={fator}[a]",
        "-map", "[v]", "-map", "[a]",
        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "28", "-pix_fmt", "yuv420p", "-c:a", "aac",
        temp_output_path
    ]
    
    process = await asyncio.create_subprocess_exec(
        *comando,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    
    if process.returncode != 0:
        print(f"Erro FFmpeg ao acelerar vídeo na distribuição: {stderr.decode()}")
        if os.path.exists(temp_output_path):
            os.remove(temp_output_path)
        raise HTTPException(status_code=500, detail="Erro ao acelerar vídeo no servidor")
        
    os.rename(temp_output_path, output_path)
        
    return FileResponse(output_path, filename=f"{base_name} ({velocidade}x).mp4", media_type="video/mp4")

@router_ui.post("/api/series/saga/{parent_id}/publicar-youtube")
async def publicar_saga_youtube(parent_id: uuid.UUID, request: Request, db: AsyncSession = Depends(get_db)):
    from app.workers.celery_app import celery_app
    import redis
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    r.sadd("processing_saga_ids", str(parent_id))
    
    celery_app.send_task("app.workers.tasks_media.publicar_serie_youtube_task", args=[str(parent_id)], queue='media_tasks')
    
    referer = request.headers.get("referer", "/distribuicao")
    return RedirectResponse(url=referer, status_code=status.HTTP_303_SEE_OTHER)

@router_ui.post("/historia/{id}/publicar-youtube")
async def publicar_youtube(id: uuid.UUID, request: Request, db: AsyncSession = Depends(get_db)):
    from app.workers.celery_app import celery_app
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        celery_app.send_task("app.workers.tasks_media.publicar_youtube_task", args=[str(id)], queue='media_tasks')
    
    referer = request.headers.get("referer", "/distribuicao")
    return RedirectResponse(url=referer, status_code=status.HTTP_303_SEE_OTHER)

@router_ui.post("/historia/{id}/publicar-manual")
async def publicar_manual(id: uuid.UUID, request: Request, url_youtube: str = Form(...), db: AsyncSession = Depends(get_db)):
    from datetime import datetime
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        historia.status = StatusHistoria.PUBLICADO
        historia.url_video_publicado = url_youtube
        historia.data_publicacao = (datetime.utcnow() - timedelta(hours=3))
        await db.commit()
    
    referer = request.headers.get("referer", "/distribuicao")
    return RedirectResponse(url=referer, status_code=status.HTTP_303_SEE_OTHER)

@router_ui.post("/historia/{id}/desfazer-publicacao")
async def desfazer_publicacao(id: uuid.UUID, request: Request, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        historia.status = StatusHistoria.DISTRIBUICAO
        historia.url_video_publicado = None
        historia.data_publicacao = None
        # Limpa métricas ao desfazer
        historia.visualizacoes_youtube = 0
        historia.comentarios_youtube = 0
        historia.likes_youtube = 0
        await db.commit()
    
    referer = request.headers.get("referer", "/distribuicao")
    return RedirectResponse(url=referer, status_code=status.HTTP_303_SEE_OTHER)

@router_ui.get("/api/ia/testar/{motor}")
async def testar_ia(motor: str, db: AsyncSession = Depends(get_db)):
    from app.db.models import ConfiguracaoSistema
    result = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
    config = result.scalars().first()
    
    if motor == "gemini":
        if not config or not config.api_key_gemini:
            raise HTTPException(status_code=400, detail="Chave Gemini não configurada.")
        try:
            import google.generativeai as genai
            genai.configure(api_key=config.api_key_gemini)
            model = genai.GenerativeModel('gemini-2.5-flash')
            res = await model.generate_content_async("Responda apenas 'OK' se estiver me ouvindo.")
            return {"status": "ok", "mensagem": "Conexão com Gemini bem-sucedida!", "resposta_ia": res.text.strip()}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
            
    elif motor == "anthropic":
        if not config or not config.api_key_anthropic:
            raise HTTPException(status_code=400, detail="Chave Anthropic não configurada.")
        try:
            from anthropic import AsyncAnthropic
            import httpx
            http_client = httpx.AsyncClient(verify=False)
            client = AsyncAnthropic(api_key=config.api_key_anthropic, http_client=http_client)
            res = await client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=10,
                messages=[{"role": "user", "content": "Responda apenas 'OK' se estiver me ouvindo."}]
            )
            return {"status": "ok", "mensagem": "Conexão com Anthropic bem-sucedida!", "resposta_ia": res.content[0].text.strip()}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
            
    raise HTTPException(status_code=400, detail="Motor desconhecido")

# --- CONFIGURAÇÕES ---

@router_ui.get("/configuracoes")
async def visualizar_configuracoes(request: Request, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    from app.db.models import ConfiguracaoSistema
    result = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
    config = result.scalars().first()
    return templates.TemplateResponse(request=request, name="configuracoes.html", context={"config": config, "badges": badges})

@router_ui.post("/configuracoes/salvar")
async def salvar_configuracoes(
    request: Request, 
    youtube_client_id: str = Form(None), 
    youtube_client_secret: str = Form(None), 
    motor_ia: str = Form(None),
    api_key_gemini: str = Form(None),
    api_key_anthropic: str = Form(None),
    elevenlabs_json: str = Form(None),
    usar_edge_tts: str = Form(None),
    subreddits_busca: str = Form(None),
    reddit_time_filters: list[str] = Form(default=["day"]),
    reddit_user_agent: str = Form(None),
    reddit_cookie: str = Form(None),
    db: AsyncSession = Depends(get_db)
):
    import json
    from app.db.models import ConfiguracaoSistema
    result = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
    config = result.scalars().first()
    if config:
        config.youtube_client_id = youtube_client_id.strip() if youtube_client_id else None
        config.youtube_client_secret = youtube_client_secret.strip() if youtube_client_secret else None
        
        if subreddits_busca:
            config.subreddits_busca = subreddits_busca
        config.reddit_time_filters = ",".join(reddit_time_filters) if reddit_time_filters else "day"
        config.reddit_user_agent = reddit_user_agent
        config.reddit_cookie = reddit_cookie
        
        if motor_ia == 'gemini':
            config.usar_gemini = True
            config.usar_anthropic = False
        elif motor_ia == 'anthropic':
            config.usar_gemini = False
            config.usar_anthropic = True
            
        config.usar_edge_tts = (usar_edge_tts == 'on')
            
        if api_key_gemini is not None:
            config.api_key_gemini = api_key_gemini.strip() if api_key_gemini.strip() else None
        if api_key_anthropic is not None:
            config.api_key_anthropic = api_key_anthropic.strip() if api_key_anthropic.strip() else None
            
        if elevenlabs_json:
            try:
                config.api_keys_elevenlabs_json = json.loads(elevenlabs_json)
            except json.JSONDecodeError:
                pass
                
        await db.commit()
    return RedirectResponse(url="/configuracoes", status_code=status.HTTP_303_SEE_OTHER)

@router_ui.get("/api/auth/youtube")
async def auth_youtube(request: Request, lang: str = "pt", db: AsyncSession = Depends(get_db)):
    from google_auth_oauthlib.flow import Flow
    from app.db.models import ConfiguracaoSistema
    
    result = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
    config = result.scalars().first()
    
    if not config or not config.youtube_client_id or not config.youtube_client_secret:
        raise HTTPException(status_code=400, detail="Client ID e Secret do YouTube não configurados.")
        
    client_config = {
        "web": {
            "client_id": config.youtube_client_id,
            "project_id": "fabrica-videos",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_secret": config.youtube_client_secret,
            "redirect_uris": ["http://localhost:8080/api/auth/youtube/callback"]
        }
    }
    
    import os
    os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'
    
    flow = Flow.from_client_config(
        client_config,
        scopes=["https://www.googleapis.com/auth/youtube.upload", "https://www.googleapis.com/auth/youtube.readonly"]
    )
    flow.redirect_uri = "http://localhost:8080/api/auth/youtube/callback"
    flow.autogenerate_code_verifier = False
    
    authorization_url, _ = flow.authorization_url(
        access_type="offline",
        include_granted_scopes="true",
        prompt="consent",
        state=lang
    )
    
    return RedirectResponse(url=authorization_url)

@router_ui.get("/api/auth/youtube/callback")
async def auth_youtube_callback(request: Request, code: str = None, error: str = None, state: str = "pt", db: AsyncSession = Depends(get_db)):
    if error:
        logger.error(f"Erro OAuth: {error}")
        return RedirectResponse(url="/configuracoes", status_code=status.HTTP_303_SEE_OTHER)
        
    if not code:
        raise HTTPException(status_code=400, detail="Código de autorização não recebido.")

    from google_auth_oauthlib.flow import Flow
    from app.db.models import ConfiguracaoSistema
    
    result = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
    config = result.scalars().first()
    
    client_config = {
        "web": {
            "client_id": config.youtube_client_id,
            "project_id": "fabrica-videos",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_secret": config.youtube_client_secret,
            "redirect_uris": ["http://localhost:8080/api/auth/youtube/callback"]
        }
    }
    
    import os
    os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'
    
    flow = Flow.from_client_config(
        client_config,
        scopes=["https://www.googleapis.com/auth/youtube.upload", "https://www.googleapis.com/auth/youtube.readonly"],
        state=state
    )
    flow.redirect_uri = "http://localhost:8080/api/auth/youtube/callback"
    flow.autogenerate_code_verifier = False
    
    auth_response_url = str(request.url)
    if auth_response_url.startswith("http://"):
        auth_response_url = auth_response_url.replace("http://", "https://", 1)
    
    flow.fetch_token(authorization_response=auth_response_url)
    credentials = flow.credentials
    
    tokens = dict(config.youtube_tokens_json or {})
    tokens[state] = {
        "access_token": credentials.token,
        "refresh_token": credentials.refresh_token,
        "expiry": credentials.expiry.isoformat() if credentials.expiry else None
    }
    config.youtube_tokens_json = tokens
    
    from sqlalchemy.orm.attributes import flag_modified
    flag_modified(config, "youtube_tokens_json")
    
    await db.commit()
    return RedirectResponse(url="/configuracoes", status_code=status.HTTP_303_SEE_OTHER)

@router_ui.get("/api/auth/youtube/testar/{lang}")
async def test_youtube_auth(lang: str, db: AsyncSession = Depends(get_db)):
    from app.db.models import ConfiguracaoSistema
    import httpx
    
    result = await db.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
    config = result.scalars().first()
    
    if not config or not config.youtube_tokens_json or lang not in config.youtube_tokens_json:
        raise HTTPException(status_code=400, detail="Token não encontrado para esse idioma.")
        
    token_data = config.youtube_tokens_json[lang]
    access_token = token_data.get("access_token")
    
    if not access_token:
        raise HTTPException(status_code=400, detail="Access token vazio.")
        
    # Testa a API de channels do YouTube
    async with httpx.AsyncClient() as client:
        res = await client.get(
            "https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true",
            headers={"Authorization": f"Bearer {access_token}"}
        )
        if res.status_code != 200:
            raise HTTPException(status_code=res.status_code, detail=f"Erro do Google: {res.text}")
            
        data = res.json()
        items = data.get("items", [])
        if not items:
            raise HTTPException(status_code=404, detail="Nenhum canal associado a esta conta Google.")
            
        channel_name = items[0]["snippet"]["title"]
        channel_id = items[0]["id"]
        
        return {"status": "ok", "channel_name": channel_name, "channel_id": channel_id}

@router_ui.get("/logs")
async def visualizar_logs(request: Request, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    from app.db.models import LogSistema
    result = await db.execute(select(LogSistema).order_by(LogSistema.data_registro.desc()).limit(100))
    logs = result.scalars().all()
    return templates.TemplateResponse(request=request, name="logs.html", context={"logs": logs, "badges": badges})


@router_ui.post("/backgrounds/baixar")
async def baixar_background(request: Request, url: str = Form(...), db: AsyncSession = Depends(get_db)):
    from app.db.models import VideoBackground
    from app.workers.tasks_media import baixar_background_task
    
    # Verifica se ja existe
    result = await db.execute(select(VideoBackground).where(VideoBackground.url_youtube == url))
    if not result.scalars().first():
        bg = VideoBackground(url_youtube=url)
        db.add(bg)
        await db.commit()
        baixar_background_task.apply_async(args=[url], queue='media_tasks')
        
    return RedirectResponse(url="/backgrounds", status_code=303)
@router_ui.post("/historia/{id}/capa-upload")
async def upload_capa(id: uuid.UUID, capa: UploadFile = File(...), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        import time
        os.makedirs('/app/assets/images', exist_ok=True)
        file_ext = capa.filename.split('.')[-1]
        timestamp = int(time.time())
        file_path = f"/app/assets/images/{id}_custom_{timestamp}.{file_ext}"
        with open(file_path, "wb") as f:
            f.write(await capa.read())
        historia.caminho_imagem_gancho = file_path
        await db.commit()
    return RedirectResponse(url=f"/historia/{id}", status_code=303)

@router_ui.post("/historia/{id}/gerar-capa-ia")
async def gerar_capa_ia(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    from app.services.ai_services import gerar_gancho_imagem_e_titulo
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        texto_base = historia.texto_narrado if historia.texto_narrado else historia.texto_original
        gancho = await gerar_gancho_imagem_e_titulo(texto_base, historia.id_post_reddit, historia.titulo_gancho)
        if gancho.get('caminho_imagem_gancho'):
            historia.caminho_imagem_gancho = gancho.get('caminho_imagem_gancho')
            historia.custo_ia_texto = (historia.custo_ia_texto or 0.0) + gancho.get('custo_ia_texto', 0.0)
            await db.commit()
    return RedirectResponse(url=f"/historia/{id}", status_code=303)
@router_ui.post("/historia/{id}/retentar-render")
async def retentar_render(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        historia.status = StatusHistoria.LIBERADO_RENDERIZACAO
        await db.commit()
        from app.workers.tasks_media import renderizar_video_task
        renderizar_video_task.apply_async(args=[str(id)], queue='media_tasks')
    return RedirectResponse(url=f"/historia/{id}", status_code=303)

@router_ui.post("/backgrounds/{bg_id}/retentar")
async def retentar_background(bg_id: int, db: AsyncSession = Depends(get_db)):
    from app.db.models import VideoBackground
    from app.workers.tasks_media import baixar_background_task
    
    result = await db.execute(select(VideoBackground).where(VideoBackground.id == bg_id))
    bg = result.scalars().first()
    
    if bg and bg.status == 'ERRO':
        bg.status = 'BAIXANDO'
        await db.commit()
        baixar_background_task.apply_async(args=[bg.url_youtube], queue='media_tasks')
        
    return RedirectResponse(url="/backgrounds", status_code=303)
@router_ui.get("/api/backgrounds/progress")
async def get_backgrounds_progress():
    import redis
    try:
        r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
        keys = r.keys('bg_progress_*')
        res = {}
        for k in keys:
            url = k.replace('bg_progress_', '')
            res[url] = r.get(k)
        return res
    except:
        return {}

@router_ui.post("/historia/{id}/gerar-capa-gratis")
async def gerar_capa_gratis(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    import os
    import time
    from google import genai
    from PIL import Image
    import io
    from app.services.ai_services import _get_config
    
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        prompt_base = historia.titulo_gancho or historia.titulo_reddit or "reddit story"
        # Prompt focado em thumbnail vertical e exigindo o texto desenhado pela IA
        prompt = f"A vertical youtube shorts thumbnail about: {prompt_base}. The image MUST include the exact text '{prompt_base}' written prominently in a bold, cinematic, readable typography. Hyper realistic, cinematic lighting, dramatic. Aspect ratio 9:16, vertical."
        
        config = await _get_config()
        if config and config.api_key_gemini:
            try:
                client = genai.Client(api_key=config.api_key_gemini)
                response = client.models.generate_content(
                    model="gemini-3.1-flash-image",
                    contents=[prompt],
                )
                
                for part in response.parts:
                    if part.inline_data is not None:
                        img_bytes = part.inline_data.data
                        os.makedirs('/app/assets/hooks', exist_ok=True)
                        timestamp = int(time.time())
                        caminho_raw = f"/app/assets/hooks/{id}_gemini_{timestamp}_raw.jpg"
                        file_path = f"/app/assets/hooks/{id}_gemini_{timestamp}.jpg"
                        
                        img = Image.open(io.BytesIO(img_bytes))
                        img.save(caminho_raw, "JPEG")
                        import shutil
                        shutil.copy(caminho_raw, file_path)
                        
                        # O Gemini já gera o texto nativamente, então não tatuamos por cima.
                        # from app.services.media_services import tatuar_capa
                        # tatuar_capa(file_path, prompt_base)
                        
                        historia.caminho_imagem_gancho = file_path
                        await db.commit()
                        break
            except Exception as e:
                import logging
                logging.error(f"Erro Gemini 3.1 Image: {e}")
                
    return RedirectResponse(url=f"/historia/{id}", status_code=303)

@router_ui.post("/historia/{id}/apagar-capa")
async def apagar_capa(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if historia:
        historia.caminho_imagem_gancho = None
        await db.commit()
    return RedirectResponse(url=f"/historia/{id}", status_code=303)
@router_ui.post("/api/historia/{id}/resumir-comentarios")
async def resumir_comentarios_endpoint(id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(HistoriaReddit).where(HistoriaReddit.id == id))
    historia = result.scalars().first()
    if not historia:
        raise HTTPException(status_code=404, detail="História não encontrada")
        
    if not historia.comentarios_reddit:
        raise HTTPException(status_code=400, detail="Sem comentários para resumir")
        
    from app.services.ai_services import resumir_comentarios_ia
    
    import json
    comentarios = historia.comentarios_reddit
    if isinstance(comentarios, str):
        try:
            parsed = json.loads(comentarios)
            if isinstance(parsed, list):
                comentarios = "\n".join(parsed)
            else:
                comentarios = str(parsed)
        except:
            pass
    elif isinstance(comentarios, list):
        comentarios = "\n".join([str(c) for c in comentarios])
        
    resumo = await resumir_comentarios_ia(historia.titulo_reddit, historia.texto_original, comentarios)
    
    historia.resumo_comentarios = resumo
    await db.commit()
    
    return RedirectResponse(url=f"/historia/{id}", status_code=303)


@router_ui.get("/backgrounds")
async def listar_backgrounds(request: Request, db: AsyncSession = Depends(get_db), badges: dict = Depends(get_menu_badges)):
    from app.db.models import VideoBackground
    import os
    result = await db.execute(select(VideoBackground).order_by(VideoBackground.criado_em.desc()))
    bgs = result.scalars().all()
    
    for bg in bgs:
        bg.tamanho_mb = 0
        if bg.status == 'PRONTO' and bg.caminho_arquivo and os.path.exists(bg.caminho_arquivo):
            tamanho_bytes = os.path.getsize(bg.caminho_arquivo)
            bg.tamanho_mb = round(tamanho_bytes / (1024 * 1024), 1)
            
    return templates.TemplateResponse(request=request, name="backgrounds.html", context={"backgrounds": bgs, "badges": badges})


