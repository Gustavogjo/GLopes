import asyncio
import sys
sys.path.append('c:\\gldo\\prj_lucro')
from app.db.session import AsyncSessionLocal
from app.db.models import HistoriaReddit
from sqlalchemy import select

async def main():
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(HistoriaReddit).where(HistoriaReddit.parent_id != None))
        historias = result.scalars().all()
        for h in historias:
            print(f"ID: {h.id}, Parte: {h.parte_numero}, Status: {h.status.value}")

if __name__ == "__main__":
    asyncio.run(main())
