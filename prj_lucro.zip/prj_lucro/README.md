# 🎥 Fábrica de Vídeos Automática (Reddit Shorts)
**Documentação Oficial do Projeto**

Este documento detalha toda a arquitetura, regras de negócio e fluxos de trabalho do sistema automatizado de criação de vídeos curtos (Shorts/TikToks) a partir de relatos do Reddit.

---

## 1. Arquitetura e Tecnologias
O sistema é uma aplicação modular e conteinerizada, desenhada para rodar tarefas pesadas de inteligência artificial e processamento de vídeo em segundo plano (background) sem travar a interface do usuário.

- **Frontend:** HTML5, Jinja2 Templates, Tailwind CSS (via CDN)
- **Backend Core:** Python 3.10, FastAPI, SQLAlchemy (Async)
- **Banco de Dados:** PostgreSQL (armazena estado das histórias, metadados e logs)
- **Mensageria e Filas:** Redis e Celery (gerenciamento de trabalhadores em background)
- **Motores de IA:** Gemini (Roteiro), ElevenLabs (Voz), Whisper (Transcrição Local), Pollinations/DALL-E (Imagens)
- **Motor Audiovisual:** FFmpeg (edição, legendagem, renderização)
- **Infraestrutura:** Docker e Docker Compose (`web`, `db`, `redis`, `worker_io`, `worker_media`)

---

## 2. O Pipeline Principal (Ciclo de Vida da História)

O processo de criação é dividido em 5 Fases principais (representadas pelos menus da aplicação):

### Fase 1: Captação (Inbox / Caixa de Entrada)
- **Worker de I/O** entra no Reddit usando cookies e headers configurados para evitar bloqueios.
- Coleta as histórias em alta (Top/Hot) dos subreddits selecionados (ex: `r/RelatosDoReddit`).
- Extrai: Título original, texto bruto, os 3 principais comentários e data de criação.
- Status: `AGUARDANDO_APROVACAO`.

### Fase 2: Curadoria e Inteligência Artificial
Na tela de "Detalhes", a história crua é analisada pela IA (Gemini).
- **O que a IA faz:**
  1. Lê o relato bruto e reescreve o roteiro focando em "storytelling de fofoca".
  2. Nunca resume a história; adiciona emoção e pausas.
  3. Dá uma nota (0 a 10) para o potencial de engajamento do relato.
  4. Escolhe o Gênero do Narrador (Masculino ou Feminino).
  5. Cria um "Título Gancho" chamativo.
  6. Gera um *prompt* detalhado de imagem para a capa do vídeo.
- Uma **Capa Visual** é gerada (DALL-E ou Pollinations) no formato 9:16. O título gancho é "tatuado" (escrito) diretamente na imagem usando a fonte Oswald.
- Status: `REVISAO_HUMANA`.

### Fase 3: Geração de Áudio e Transcrição (Motor Parte 1)
Após a aprovação do roteiro pelo usuário, a história é enviada para o Worker de Mídia.
- O texto é enviado para a **ElevenLabs** através de um túnel seguro de WebSockets (bypass de firewalls corporativos).
- O áudio (MP3) é salvo e analisado:
  - Se tiver menos de **65 segundos**: Reprovado automaticamente (muito curto).
  - Entre **65s e 89s**: Pausado para revisão manual (risco de baixa retenção).
  - Mais de **150 segundos**: O sistema acelera o áudio automaticamente (até 1.3x) na renderização para caber no formato de Shorts.
- O áudio é passado para o **Whisper Local** que transcreve cada palavra e seu tempo exato de fala (JSON), gerando as legendas hiper-precisas.
- Status: `AUDIO_PRONTO`. (O usuário pode ouvir o áudio antes de renderizar).

### Fase 4: Renderização de Vídeo (Motor Parte 2)
Após a aprovação do áudio, o FFmpeg entra em ação:
- Escolhe um vídeo de "Gameplay" (fundo) aleatório da pasta `assets/backgrounds`.
- Adiciona a Capa nos primeiros segundos (com efeito de Zoom-in leve).
- Centraliza o Gameplay com um desfoque (boxblur) nas bordas superior e inferior (fundo infinito).
- Insere as legendas animadas (karaokê/highlight amarelo) no centro da tela sincronizadas com a voz.
- Une o áudio finalizado e renderiza um MP4 pesado e profissional.
- Status: `BETA_PRONTO` (O vídeo aparece na aba "Acervo").

### Fase 5: Publicação
- O Worker de I/O pega o MP4 renderizado e faz o upload automático para o canal do YouTube configurado via OAuth2.
- Status final: `PUBLICADO`.

---

## 3. Regras de Negócio e "Quality Gates"

Para garantir que apenas vídeos excelentes sejam renderizados (poupando tempo e custo computacional), o sistema usa "Quality Gates" (Portões de Qualidade):

1. **Revisão de Texto:** O usuário pode descartar lixo ou pedir para a IA reescrever até o roteiro ficar perfeito. O usuário pode fazer upload de uma capa própria se a da IA ficar ruim.
2. **Revisão de Áudio:** O áudio é gerado *antes* do vídeo. Se a entonação da IA não ficar legal, ou der erro, o usuário não perdeu 3 minutos renderizando um vídeo inútil.
3. **Erros Fatais Transparentes:** 
   - Se a geração de áudio falhar -> `ERRO_FATAL_AUDIO`
   - Se o FFmpeg falhar -> `ERRO_FATAL_RENDERIZACAO`
   - O usuário tem um botão de "Tentar Novamente" na própria tela da história para reenviar o comando sem perder o progresso anterior.
4. **Gerenciamento de Fundo (Backgrounds):**
   - Na tela "Backgrounds", o usuário cola links do YouTube (ex: *Minecraft Parkour*) e o sistema faz o download assíncrono em alta qualidade usando `yt-dlp`. Esses vídeos alimentam a esteira de renderização.

---

## 4. Estrutura de Diretórios Críticos

- `app/db/`: Modelos do Banco de Dados e Conexão (PostgreSQL).
- `app/api/`: Rotas de Interface (UI) e Endpoints de controle.
- `app/services/`: "Cérebros" da aplicação:
  - `ai_services.py`: Comunicação com Gemini e Prompts.
  - `elevenlabs_service.py`: Comunicação WebSocket com ElevenLabs.
  - `reddit_service.py`: Scraping robusto de comentários e relatos.
  - `whisper_service.py`: Transcrição de áudio via IA Open-Source.
  - `media_services.py`: O coração do FFmpeg, edição e pintura de imagem (Pillow).
- `app/workers/`: Trabalhadores do Celery (`tasks_io.py` para internet, `tasks_media.py` para CPU pesada).
- `app/output/`: Onde os arquivos temporários, de áudio e vídeos prontos (MP4) são salvos.
- `app/assets/`: Arquivos estáticos (fontes, hooks de imagem, vídeos de gameplay).

---

## 5. Resumo do Estado Atual (O que já está pronto?)

✅ **Mineração e Scraping:** Funcionando perfeitamente (captura textos e comentários).
✅ **Módulo de IA (Curadoria):** Gemini configurado para não resumir a história. Capas sendo geradas, recortadas e tatuadas com fontes dinâmicas.
✅ **Motor Audiovisual 2.0:** Pipeline quebrado em duas etapas seguras (Áudio > Renderização).
✅ **Bypass de Firewall:** ElevenLabs funcionando 100% via WebSocket, blindado contra interceptações corporativas (Zscaler/PaloAlto).
✅ **Interface do Usuário (UI):** Layout escuro cinematográfico, painéis de erro robustos, contadores de menu dinâmicos, e players de áudio e vídeo embutidos.
✅ **Download de Backgrounds:** `yt-dlp` baixando vídeos do YouTube diretamente na tela de configurações.
