import os
import sys
from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool
from alembic import context
from dotenv import load_dotenv

# Insere a raiz do projeto no PYTHONPATH para localizar app/
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Importa a Base que acopla todos os metadados (models)
from app.db.session import Base
from app.db.models import HistoriaReddit

# Carrega as credenciais dinâmicas do .env
load_dotenv()

# O objeto de configuração (ini config)
config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Define as constraints a serem lidas e gerenciadas
target_metadata = Base.metadata

# Sobrescreve a string de conexão para utilizar o URL de sincronização extraído dinamicamente
# Usa psycopg2 driver porque o Alembic roda operações DDL de forma síncrona
db_url = os.getenv("DATABASE_URL_SYNC", "postgresql://admin:senha_forte@localhost:5432/fabrica_videos_db")
config.set_main_option("sqlalchemy.url", db_url)


def run_migrations_offline() -> None:
    """Executa as migrações de forma 'offline'."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Executa as migrações conectadas diretamente ao DB."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection, target_metadata=target_metadata
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
