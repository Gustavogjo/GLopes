import asyncio
import time
from sqlalchemy import select
from app.db.session import AsyncSessionLocal
from app.db.models import HistoriaReddit, StatusHistoria, ConfiguracaoSistema
from app.services.reddit_service import obter_comentarios_post

async def main():
    async with AsyncSessionLocal() as session:
        # Pega a configuração para usar cookie/user-agent se existir
        res_config = await session.execute(select(ConfiguracaoSistema).where(ConfiguracaoSistema.id == 1))
        config = res_config.scalars().first()
        cookie = config.reddit_cookie if config else None
        ua = config.reddit_user_agent if config else None

        # Pega as histórias na caixa de entrada (AGUARDANDO_APROVACAO) e curadoria (REVISAO_HUMANA)
        result = await session.execute(
            select(HistoriaReddit)
            .where(HistoriaReddit.status.in_([StatusHistoria.AGUARDANDO_APROVACAO, StatusHistoria.REVISAO_HUMANA]))
        )
        historias = result.scalars().all()
        total = len(historias)
        print(f"Total de histórias para atualizar: {total}")

        for i, h in enumerate(historias, 1):
            print(f"[{i}/{total}] Atualizando comentários de: {h.id_post_reddit} ({h.subreddit})...")
            try:
                comentarios = await asyncio.to_thread(
                    obter_comentarios_post, 
                    h.id_post_reddit, 
                    20, 
                    h.subreddit, 
                    cookie, 
                    ua
                )
                if comentarios:
                    h.comentarios_reddit = comentarios
                    await session.commit()
                    print(f"  -> Sucesso! Comentários atualizados.")
                else:
                    print(f"  -> Sem comentários novos ou falha.")
            except Exception as e:
                print(f"  -> Erro ao atualizar {h.id_post_reddit}: {e}")
            
            # Rate limiting do Reddit: 1.5s entre requisições
            time.sleep(1.5)

if __name__ == "__main__":
    asyncio.run(main())
